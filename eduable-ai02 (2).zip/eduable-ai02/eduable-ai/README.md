# EduAble AI

"Learning Without Barriers." — AI-powered, accessibility-first learning dashboard.

## Structure

```
eduable-ai/
├─ frontend/     # React + Vite + Tailwind — full working UI (see frontend/README.md)
└─ backend/      # empty folder structure only, ready for API implementation (see backend/README.md)
```

## Quick start (frontend)

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173

## Next steps

1. Implement the backend inside `backend/` (Node/Express suggested — structure
   already scaffolded, see `backend/README.md` for suggested routes).
2. Point `frontend/.env` → `VITE_API_BASE_URL` at your backend.
3. Swap the mock data in `frontend/src/data/mockData.js` for real API calls via
   `frontend/src/utils/api.js`.
