/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f2f0ff',
          100: '#e6e2ff',
          200: '#cec5ff',
          300: '#ab9bff',
          400: '#8b6cff',
          500: '#6C4DF6',
          600: '#5b37ef',
          700: '#4c2ad1',
          800: '#3f24aa',
          900: '#352186',
        },
        accentPink: '#EC4899',
        accentOrange: '#F59E0B',
        accentGreen: '#22C55E',
        accentBlue: '#3B82F6',
        surface: '#F7F7FC',
        card: '#FFFFFF',
      },
      fontFamily: {
        sans: ['Poppins', 'Inter', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      boxShadow: {
        card: '0 2px 10px rgba(76, 42, 209, 0.06)',
        soft: '0 6px 24px rgba(76, 42, 209, 0.10)',
      },
    },
  },
  plugins: [],
}
