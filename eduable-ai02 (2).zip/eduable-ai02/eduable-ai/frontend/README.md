# EduAble AI — Frontend

React (Vite) + Tailwind CSS implementation of the EduAble AI dashboard UI.

## Setup

```bash
cd frontend
npm install
npm run dev
```

App runs at `http://localhost:5173`.

Copy `.env.example` to `.env` and set `VITE_API_BASE_URL` to point at your backend
(defaults to `http://localhost:5000/api`).

## Folder structure

```
frontend/
├─ public/                 # static assets served as-is
├─ src/
│  ├─ assets/images/       # local images/illustrations
│  ├─ components/
│  │  ├─ layout/           # Sidebar, Header, Footer (app shell)
│  │  ├─ dashboard/        # one component per dashboard section/module
│  │  └─ common/           # generic reusable UI (Card, ProgressRing, ProgressBar)
│  ├─ context/             # React context (global state, e.g. UserContext)
│  ├─ data/                # mockData.js — demo data, swap for API responses
│  ├─ hooks/                # custom hooks (useAuth, etc.)
│  ├─ pages/                # route-level pages (DashboardPage, ...)
│  ├─ styles/               # global Tailwind CSS
│  ├─ utils/api.js          # axios client + endpoint groups matching backend routes
│  ├─ App.jsx
│  └─ main.jsx
├─ index.html
├─ tailwind.config.js
├─ postcss.config.js
├─ vite.config.js
└─ package.json
```

## Routing — each module is its own page

The Dashboard (`/`) only shows the overview: hero banner, quick access cards,
recent activities, learning insights, upload content, learner profile and
AI generated output. Every numbered module opens on its own page instead of
being stacked on the dashboard:

| Route              | Page                     |
|---------------------|--------------------------|
| `/`                 | Dashboard (overview)     |
| `/learn-easy`       | LearnEasyPage            |
| `/concept-coach`    | ConceptCoachPage         |
| `/my-world`         | MyWorldPage              |
| `/access-check`     | AccessCheckPage          |
| `/learning-path`    | LearningPathPage         |
| `/study-companion`  | StudyCompanionPage       |

- Sidebar nav items and the Quick Access cards both link straight to these
  routes (see `src/data/mockData.js` — each entry has a `path`).
- Each module page uses the shared `PageShell` (`src/components/layout/PageShell.jsx`)
  which adds a "Back to Dashboard" link, page title, and the footer.
- To add a new page: create it in `src/pages/`, wrap its content in
  `PageShell`, then register the route in `App.jsx`.

## Notes

- All dashboard data currently comes from `src/data/mockData.js`. Replace each
  section's data source with a call to the matching function in
  `src/utils/api.js` once the backend endpoints are ready.
