import PageShell from '../components/layout/PageShell'
import UploadContent from '../components/dashboard/UploadContent'
import LearnerProfile from '../components/dashboard/LearnerProfile'
import AiGeneratedOutput from '../components/dashboard/AiGeneratedOutput'

export default function LearnEasyPage() {
  return (
    <PageShell title="LearnEasy" subtitle="Universal Learning Transformer — transform any lesson into your perfect learning style.">
      <div className="grid md:grid-cols-3 gap-5">
        <UploadContent />
        <LearnerProfile />
        <AiGeneratedOutput />
      </div>
    </PageShell>
  )
}
