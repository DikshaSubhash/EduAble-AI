import PageShell from '../components/layout/PageShell'
import StudyCompanion from '../components/dashboard/StudyCompanion'

export default function StudyCompanionPage() {
  return (
    <PageShell title="AI Study Companion" subtitle="Your smart companion for better revision.">
      <StudyCompanion />
    </PageShell>
  )
}
