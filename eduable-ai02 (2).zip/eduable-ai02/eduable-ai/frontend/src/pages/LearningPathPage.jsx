import PageShell from '../components/layout/PageShell'
import MyLearningPath from '../components/dashboard/MyLearningPath'

export default function LearningPathPage() {
  return (
    <PageShell title="My Learning Path" subtitle="AI Learning Journey — your personalized roadmap to mastering the syllabus.">
      <MyLearningPath />
    </PageShell>
  )
}
