import PageShell from '../components/layout/PageShell'
import MyWorld from '../components/dashboard/MyWorld'

export default function MyWorldPage() {
  return (
    <PageShell title="My World" subtitle="LifeLens Learning — learn through real-life examples from the world you love.">
      <MyWorld />
    </PageShell>
  )
}
