import PageShell from '../components/layout/PageShell'
import AccessCheck from '../components/dashboard/AccessCheck'

export default function AccessCheckPage() {
  return (
    <PageShell title="Access Check" subtitle="Accessibility Intelligence Score — see how accessible and inclusive your content is.">
      <AccessCheck />
    </PageShell>
  )
}
