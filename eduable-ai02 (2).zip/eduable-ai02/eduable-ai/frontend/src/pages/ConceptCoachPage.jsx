import PageShell from '../components/layout/PageShell'
import ConceptCoach from '../components/dashboard/ConceptCoach'

export default function ConceptCoachPage() {
  return (
    <PageShell title="Concept Coach" subtitle="Misconception X-Ray — we don't just mark answers, we find the root of misunderstanding.">
      <ConceptCoach />
    </PageShell>
  )
}
