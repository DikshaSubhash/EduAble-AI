import Header from '../components/layout/Header'
import Footer from '../components/layout/Footer'
import HeroBanner from '../components/dashboard/HeroBanner'
import QuickAccess from '../components/dashboard/QuickAccess'
import RecentActivities from '../components/dashboard/RecentActivities'
import LearningInsights from '../components/dashboard/LearningInsights'

// Dashboard = pure overview only: hero, quick access to modules, recent
// activity and learning insights. Upload/Profile/AI-Output live on the
// LearnEasy page, and every other numbered module has its own page too
// (see src/pages/*Page.jsx and the routes wired up in App.jsx).
export default function DashboardPage() {
  return (
    <div>
      <Header />

      <div className="flex flex-col gap-5">
        <HeroBanner />
        <QuickAccess />
        <div className="grid md:grid-cols-2 gap-5">
          <RecentActivities />
          <LearningInsights />
        </div>
      </div>

      <Footer />
    </div>
  )
}
