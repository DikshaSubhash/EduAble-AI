import { Routes, Route } from 'react-router-dom'
import Sidebar from './components/layout/Sidebar'
import DashboardPage from './pages/DashboardPage'
import LearnEasyPage from './pages/LearnEasyPage'
import ConceptCoachPage from './pages/ConceptCoachPage'
import MyWorldPage from './pages/MyWorldPage'
import AccessCheckPage from './pages/AccessCheckPage'
import LearningPathPage from './pages/LearningPathPage'
import StudyCompanionPage from './pages/StudyCompanionPage'

function App() {
  return (
    <div className="flex bg-surface min-h-screen">
      <Sidebar />
      <main className="flex-1 p-4 md:p-6 max-w-[1600px] mx-auto w-full">
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/learn-easy" element={<LearnEasyPage />} />
          <Route path="/concept-coach" element={<ConceptCoachPage />} />
          <Route path="/my-world" element={<MyWorldPage />} />
          <Route path="/access-check" element={<AccessCheckPage />} />
          <Route path="/learning-path" element={<LearningPathPage />} />
          <Route path="/study-companion" element={<StudyCompanionPage />} />
        </Routes>
      </main>
    </div>
  )
}

export default App
