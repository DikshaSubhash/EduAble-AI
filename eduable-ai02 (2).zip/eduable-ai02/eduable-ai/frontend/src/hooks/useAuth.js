// Placeholder hook — wire up to backend /auth endpoints once available.
import { useState } from 'react'

export function useAuth() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(false)

  const login = async (_credentials) => {
    // TODO: call authApi.login from src/utils/api.js
  }

  const logout = () => {
    localStorage.removeItem('eduable_token')
    setUser(null)
  }

  return { user, loading, login, logout }
}
