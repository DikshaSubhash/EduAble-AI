import axios from 'axios'

// Base URL comes from Vite env variable, falls back to local backend port.
const BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api'

const api = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
})

// Attach auth token automatically once auth is implemented on the backend.
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('eduable_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// ---- Endpoint groups (to be implemented by backend team) --------------
export const authApi = {
  login: (payload) => api.post('/auth/login', payload),
  register: (payload) => api.post('/auth/register', payload),
  me: () => api.get('/auth/me'),
}

export const contentApi = {
  upload: (formData) =>
    api.post('/content/upload', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
  processWithNova: (contentId, learnerProfile) =>
    api.post(`/content/${contentId}/process`, { learnerProfile }),
}

export const conceptCoachApi = {
  getQuiz: (topicId) => api.get(`/concept-coach/quiz/${topicId}`),
  submitAnswer: (quizId, answer) => api.post(`/concept-coach/quiz/${quizId}/answer`, { answer }),
}

export const myWorldApi = {
  getExplanation: (conceptId, worldKey) => api.get(`/my-world/${conceptId}`, { params: { world: worldKey } }),
}

export const accessCheckApi = {
  analyze: (contentId) => api.post(`/access-check/${contentId}/analyze`),
}

export const learningPathApi = {
  getPath: (studentId) => api.get(`/learning-path/${studentId}`),
}

export const studyCompanionApi = {
  getFlashcards: (topicId) => api.get(`/study-companion/flashcards/${topicId}`),
  generateQuiz: (topicId) => api.post(`/study-companion/quiz/${topicId}`),
}

export const insightsApi = {
  getSummary: (studentId) => api.get(`/insights/${studentId}`),
}

export default api
