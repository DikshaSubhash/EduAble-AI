// Centralised mock/demo data.
// Replace each export with an API call (see src/utils/api.js) once the backend is live.

export const sidebarNav = [
  { key: 'dashboard', label: 'Dashboard', icon: 'LayoutGrid', path: '/' },
  { key: 'learneasy', label: 'LearnEasy', icon: 'BookOpen', desc: 'Universal Learning Transformer', path: '/learn-easy' },
  { key: 'concept-coach', label: 'Concept Coach', icon: 'Brain', desc: 'Misconception X-Ray', path: '/concept-coach' },
  { key: 'my-world', label: 'My World', icon: 'Globe2', desc: 'LifeLens Learning', path: '/my-world' },
  { key: 'access-check', label: 'Access Check', icon: 'Accessibility', desc: 'Accessibility Intelligence Score', path: '/access-check' },
  { key: 'learning-path', label: 'My Learning Path', icon: 'Route', desc: 'AI Learning Journey', path: '/learning-path' },
  { key: 'study-companion', label: 'AI Study Companion', icon: 'GraduationCap', desc: 'Revision & Practice', path: '/study-companion' },
]

export const sidebarSecondaryNav = [
  { key: 'insights', label: 'Insights', icon: 'BarChart3', desc: 'Learning Insights' },
  { key: 'activity', label: 'Activity', icon: 'History', desc: 'Recent Activities' },
  { key: 'profile', label: 'Profile', icon: 'User' },
  { key: 'settings', label: 'Settings', icon: 'Settings' },
  { key: 'help', label: 'Help & Support', icon: 'LifeBuoy' },
  { key: 'logout', label: 'Logout', icon: 'LogOut' },
]

export const currentUser = {
  name: 'Ananya Sharma',
  className: 'Class 10',
  avatarInitials: 'AS',
  plan: 'Premium Learner',
}

export const heroStats = [
  { label: 'Active Modules', value: '5' },
  { label: 'Lessons Completed', value: '12' },
  { label: 'Concepts Understood', value: '89%' },
  { label: 'Focus Session', value: '7 min' },
]

export const quickAccessModules = [
  { id: 1, title: 'LearnEasy', desc: 'Universal Learning Transformer', text: 'Transform any lesson into your perfect learning style.', icon: 'BookOpen', color: 'bg-indigo-500', path: '/learn-easy' },
  { id: 2, title: 'Concept Coach', desc: 'Misconception X-Ray', text: 'Find the root cause and build true understanding.', icon: 'Brain', color: 'bg-fuchsia-500', path: '/concept-coach' },
  { id: 3, title: 'My World', desc: 'LifeLens Learning', text: 'Learn through examples that connect with you.', icon: 'Globe2', color: 'bg-amber-500', path: '/my-world' },
  { id: 4, title: 'Access Check', desc: 'Accessibility Score', text: 'Check how accessible and inclusive your content is.', icon: 'Accessibility', color: 'bg-sky-500', path: '/access-check' },
  { id: 5, title: 'My Learning Path', desc: 'AI Learning Journey', text: 'Your personalized learning roadmap.', icon: 'Route', color: 'bg-rose-500', path: '/learning-path' },
]

export const recentActivities = [
  { id: 1, title: 'Physics - Chapter 2.pdf', subtitle: 'LearnEasy (Simplified)', time: '10 min ago', icon: 'FileText', color: 'text-rose-500 bg-rose-50' },
  { id: 2, title: 'Biology: Photosynthesis', subtitle: 'Concept Coach', time: '1 hour ago', icon: 'Leaf', color: 'text-emerald-500 bg-emerald-50' },
  { id: 3, title: 'Maths - Algebra Basics', subtitle: 'My Learning Path Updated', time: '2 hours ago', icon: 'Sigma', color: 'text-indigo-500 bg-indigo-50' },
  { id: 4, title: 'Chemistry - Acids & Bases', subtitle: 'Access Check Completed', time: 'Yesterday', icon: 'FlaskConical', color: 'text-amber-500 bg-amber-50' },
  { id: 5, title: 'LifeLens: Farming Concepts', subtitle: 'My World', time: 'Yesterday', icon: 'Sprout', color: 'text-lime-600 bg-lime-50' },
]

export const learningInsightStats = [
  { label: 'Concepts Mastered', value: '24', delta: '20% from last week' },
  { label: 'Accuracy', value: '78%', delta: '9% from last week' },
  { label: 'Study Time', value: '7.2 hrs', delta: '12% from last week' },
]

export const understandingOverview = {
  percent: 78,
  breakdown: [
    { label: 'Strong', value: 60, color: '#22C55E' },
    { label: 'Needs Practice', value: 25, color: '#F59E0B' },
    { label: 'Weak', value: 15, color: '#EF4444' },
  ],
}

export const learnerProfileOptions = [
  { key: 'visual', label: 'Visually Impaired', icon: 'Eye' },
  { key: 'dyslexia', label: 'Dyslexia-Friendly', icon: 'SpellCheck', active: true },
  { key: 'hearing', label: 'Hearing Impaired', icon: 'Ear' },
  { key: 'language', label: 'Language Selection', icon: 'Languages' },
  { key: 'beginner', label: 'Beginner', icon: 'GraduationCap' },
  { key: 'advanced', label: 'Advanced', icon: 'Sparkles' },
]

export const aiGeneratedOutputs = [
  { key: 'simplified', title: 'Simplified Version', desc: 'Easy to understand and clear', icon: 'FileText', color: 'text-indigo-500 bg-indigo-50' },
  { key: 'audio', title: 'Audio-Friendly Script', desc: 'Text optimized for audio', icon: 'Headphones', color: 'text-fuchsia-500 bg-fuchsia-50' },
  { key: 'translated', title: 'Translated Version', desc: 'Content in your preferred language', icon: 'Languages', color: 'text-sky-500 bg-sky-50' },
  { key: 'bullets', title: 'Bullet Notes', desc: 'Key points in bullet format', icon: 'ListChecks', color: 'text-amber-500 bg-amber-50' },
  { key: 'concepts', title: 'Key Concepts', desc: 'Important concepts explained', icon: 'Lightbulb', color: 'text-emerald-500 bg-emerald-50' },
]

export const conceptCoach = {
  question: 'Q1. What is the unit of Force?',
  options: ['Joule', 'Newton', 'Second', 'Degree'],
  correctIndex: 1,
  yourAnswer: 'B. Newton',
  strengths: 'Understands basic units & physical quantities.',
  commonMistake: 'Confusing unit with scalar quantities.',
  rootCause: 'Concept of Force & unit not clear.',
  betterExplanation: 'Force is a push or pull. Its SI unit is Newton (N).',
  recommendedTopic: 'Units and Measurements',
  understanding: {
    percent: 65,
    label: 'Needs Practice',
    bands: [
      { label: 'Excellent', range: '80 - 100%', color: '#22C55E' },
      { label: 'Needs Practice', range: '40 - 79%', color: '#F59E0B' },
      { label: 'Weak', range: '0 - 39%', color: '#EF4444' },
    ],
  },
}

export const worldChoices = [
  { key: 'cricket', label: 'Cricket', icon: 'Zap', active: true },
  { key: 'farming', label: 'Farming', icon: 'Wheat' },
  { key: 'automobile', label: 'Automobile', icon: 'Car' },
  { key: 'technology', label: 'Technology', icon: 'Cpu' },
  { key: 'cooking', label: 'Cooking', icon: 'ChefHat' },
  { key: 'healthcare', label: 'Healthcare', icon: 'HeartPulse' },
  { key: 'aviation', label: 'Aviation', icon: 'Plane' },
  { key: 'music', label: 'Music', icon: 'Music' },
]

export const myWorldExplanation = {
  originalConcept: "Newton's Third Law",
  exampleTitle: 'Cricket Example',
  text: 'In cricket, when a batsman hits the ball, the bat applies a force on the ball, and the ball applies an equal and opposite force on the bat. That\u2019s why the bat vibrates in the batsman\u2019s hands.',
}

export const accessibilityReport = {
  score: 92,
  maxScore: 100,
  label: 'Highly Accessible',
  fileName: 'Physics_Chapter_2.pdf',
  fileSize: '2.4 MB',
  metrics: [
    { label: 'Language Clarity', value: 95 },
    { label: 'Image Description', value: 88 },
    { label: 'Text Readability', value: 91 },
    { label: 'Contrast & Colors', value: 93 },
    { label: 'Audio Available', value: 85 },
    { label: 'Inclusive Content', value: 90 },
  ],
  suggestions: [
    'Great use of simple language.',
    'Add alt text for graphics in 5 images.',
    'Consider adding audio summary for better access.',
    'Break long paragraphs into smaller sections.',
  ],
}

export const learningPath = {
  student: {
    name: 'Ananya Sharma',
    className: 'Class 10',
    learningStyle: 'Visual Learner',
    focusLevel: 'Good',
    preferredLanguage: 'English',
    goal: 'Concept Clarity + Exam Prep',
  },
  timeline: [
    { title: 'Chapter 1: Motion in One Dimension', status: 'done' },
    { title: 'Chapter 2: Motion in One Dimension', status: 'done' },
    { title: 'Chapter 3: Laws of Motion', status: 'next' },
    { title: 'Chapter 4: Work, Energy & Power', status: 'pending' },
    { title: 'Chapter 5: Gravitation', status: 'pending' },
  ],
  roadmap: {
    keyConcepts: 12,
    revisionNeeded: 5,
    strongAreas: 'Force & Laws of Motion',
    weakTopics: 7,
    estimatedStudyTime: '5 hrs',
    targetCompletionDate: '25 May 2026',
  },
}

export const studyCompanion = {
  tools: [
    { key: 'flashcards', title: 'Flashcards', desc: '26 cards ready', icon: 'Layers' },
    { key: 'quiz', title: 'Quiz Generator', desc: '15 quiz sets ready', icon: 'ListChecks' },
    { key: 'summary', title: 'Concept Summary', desc: 'Auto-generated', icon: 'FileText' },
    { key: 'revision', title: 'Revision Sheet', desc: 'Printable PDF', icon: 'FileDown' },
  ],
  whatsNext: 'Your next revision is scheduled for Tomorrow, 5 PM',
  quickActions: ['Practice Quiz', 'Smart Notes', 'Mind Map', 'Formula Sheet'],
  todaysGoal: { completed: 2, total: 5, tasks: ['Revise Chapter 2', 'Practice 10 MCQs', 'Watch Concept Video'] },
  downloadCenter: ['Notes PDF', 'Summary PDF', 'Flashcards PDF', 'Mind Map PDF'],
}
