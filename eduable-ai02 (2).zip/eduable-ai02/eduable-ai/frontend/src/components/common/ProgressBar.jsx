export default function ProgressBar({ value = 0, color = 'bg-primary-500', trackColor = 'bg-slate-100', height = 'h-1.5' }) {
  return (
    <div className={`w-full ${trackColor} rounded-full ${height} overflow-hidden`}>
      <div className={`${color} ${height} rounded-full transition-all`} style={{ width: `${value}%` }} />
    </div>
  )
}
