import { Search, Bell, ChevronDown, HelpCircle } from 'lucide-react'
import { currentUser } from '../../data/mockData'

export default function Header() {
  return (
    <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
      <div>
        <h1 className="text-xl md:text-2xl font-bold text-slate-800">Good Morning, {currentUser.name.split(' ')[0]}! 👋</h1>
        <p className="text-sm text-slate-400">Let's make learning personalized, inclusive and powerful.</p>
      </div>

      <div className="flex items-center gap-3 ml-auto">
        <div className="hidden md:flex items-center gap-2 bg-white border border-slate-200 rounded-xl px-3 py-2 w-64">
          <Search size={16} className="text-slate-400" />
          <input
            className="bg-transparent outline-none text-sm w-full placeholder:text-slate-400"
            placeholder="Search anything..."
          />
        </div>

        <button className="relative w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center">
          <Bell size={18} className="text-slate-500" />
          <span className="absolute top-2 right-2 w-1.5 h-1.5 bg-rose-500 rounded-full" />
        </button>

        <button className="flex items-center gap-2 bg-white border border-slate-200 rounded-xl pl-1.5 pr-2 py-1.5">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary-400 to-fuchsia-400 flex items-center justify-center text-white text-xs font-semibold">
            {currentUser.avatarInitials}
          </div>
          <ChevronDown size={14} className="text-slate-400" />
        </button>

        <button className="hidden md:flex items-center gap-1.5 border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-500 bg-white">
          <HelpCircle size={14} />
          How it works?
        </button>
      </div>
    </header>
  )
}
