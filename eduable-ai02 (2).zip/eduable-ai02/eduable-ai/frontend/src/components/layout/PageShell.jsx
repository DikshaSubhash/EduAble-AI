import { Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import Footer from '../layout/Footer'

export default function PageShell({ title, subtitle, children }) {
  return (
    <div>
      <div className="mb-6">
        <Link to="/" className="inline-flex items-center gap-1.5 text-xs font-medium text-primary-500 mb-3">
          <ArrowLeft size={14} /> Back to Dashboard
        </Link>
        <h1 className="text-xl md:text-2xl font-bold text-slate-800">{title}</h1>
        {subtitle && <p className="text-sm text-slate-400">{subtitle}</p>}
      </div>

      <div className="flex flex-col gap-5">{children}</div>

      <Footer />
    </div>
  )
}
