import * as Icons from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'
import { sidebarNav, sidebarSecondaryNav } from '../../data/mockData'

function NavItem({ item }) {
  const location = useLocation()
  const active = item.path ? location.pathname === item.path : false
  const Icon = Icons[item.icon] || Icons.Circle

  const content = (
    <>
      <Icon size={18} className={`mt-0.5 shrink-0 ${active ? 'text-white' : 'text-primary-500'}`} />
      <span>
        <span className="block text-sm font-medium leading-tight">{item.label}</span>
        {item.desc && (
          <span className={`block text-[11px] leading-tight ${active ? 'text-white/80' : 'text-slate-400'}`}>
            {item.desc}
          </span>
        )}
      </span>
    </>
  )

  const className = `w-full flex items-start gap-3 px-3 py-2.5 rounded-xl text-left transition-colors ${
    active ? 'bg-primary-500 text-white shadow-soft' : 'hover:bg-primary-50 text-slate-600'
  }`

  if (item.path) {
    return (
      <Link to={item.path} className={className}>
        {content}
      </Link>
    )
  }

  return <button className={className}>{content}</button>
}

export default function Sidebar() {
  return (
    <aside className="hidden lg:flex flex-col w-64 shrink-0 bg-white border-r border-slate-100 h-screen sticky top-0 overflow-y-auto scrollbar-thin px-4 py-5">
      <Link to="/" className="flex items-center gap-2 px-2 mb-6">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-500 to-fuchsia-500 flex items-center justify-center text-white">
          <Icons.Sparkles size={18} />
        </div>
        <div>
          <p className="font-bold text-slate-800 leading-tight">EduAble AI</p>
          <p className="text-[10px] text-slate-400 leading-tight">Learning Without Barriers.</p>
        </div>
      </Link>

      <nav className="flex flex-col gap-1">
        {sidebarNav.map((item) => (
          <NavItem key={item.key} item={item} />
        ))}
      </nav>

      <div className="h-px bg-slate-100 my-4" />

      <nav className="flex flex-col gap-1">
        {sidebarSecondaryNav.map((item) => (
          <NavItem key={item.key} item={item} />
        ))}
      </nav>

      <div className="mt-6 rounded-2xl bg-gradient-to-br from-primary-600 to-fuchsia-600 text-white p-4">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
            <Icons.Bot size={16} />
          </div>
          <div>
            <p className="text-sm font-semibold leading-tight">NOVA™ AI Assistant</p>
            <p className="text-[10px] text-white/70 leading-tight">Your Learning Companion</p>
          </div>
        </div>
        <p className="text-xs text-white/85 mb-3">
          Hi! I'm NOVA, powered by Google Gemma 4. How can I help you learn today?
        </p>
        <button className="w-full bg-white/15 hover:bg-white/25 transition-colors text-xs font-medium rounded-lg py-2">
          Chat with NOVA
        </button>
      </div>

      <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-3 flex items-center gap-2">
        <Icons.Crown size={18} className="text-amber-500" />
        <div>
          <p className="text-xs font-semibold text-slate-800 leading-tight">Premium Learner</p>
          <p className="text-[10px] text-slate-400 leading-tight">Pro Plan</p>
        </div>
      </div>
    </aside>
  )
}
