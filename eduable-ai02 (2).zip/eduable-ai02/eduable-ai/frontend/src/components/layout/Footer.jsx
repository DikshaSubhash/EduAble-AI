import { Sparkles, Cpu, Users, Route, Heart } from 'lucide-react'

const FEATURES = [
  { icon: Cpu, title: 'Powered by', subtitle: 'Google Gemma 4' },
  { icon: Users, title: 'Adaptive', subtitle: 'For Every Learner' },
  { icon: Route, title: 'Inclusive', subtitle: 'For Every Need' },
  { icon: Sparkles, title: 'Intelligent', subtitle: 'For Every Path' },
]

export default function Footer() {
  return (
    <footer className="mt-8 rounded-2xl bg-gradient-to-r from-primary-600 to-fuchsia-600 text-white px-6 py-5 flex flex-wrap items-center justify-between gap-4">
      <div className="flex items-center gap-2">
        <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center">
          <Sparkles size={18} />
        </div>
        <div>
          <p className="font-bold leading-tight">EduAble AI™</p>
          <p className="text-[11px] text-white/70 leading-tight">Learning Without Barriers.</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-4">
        {FEATURES.map((f) => (
          <div key={f.title} className="flex items-center gap-2 bg-white/10 rounded-xl px-3 py-2">
            <f.icon size={16} />
            <div>
              <p className="text-xs font-semibold leading-tight">{f.title}</p>
              <p className="text-[10px] text-white/70 leading-tight">{f.subtitle}</p>
            </div>
          </div>
        ))}
      </div>

      <p className="flex items-center gap-1.5 text-xs text-white/80">
        Made with <Heart size={12} className="text-rose-300 fill-rose-300" /> for learners everywhere.
      </p>
    </footer>
  )
}
