import * as Icons from 'lucide-react'
import { Download, Headphones, Save } from 'lucide-react'
import { aiGeneratedOutputs } from '../../data/mockData'

export default function AiGeneratedOutput() {
  return (
    <div className="card">
      <h3 className="card-title">AI Generated Output</h3>
      <p className="card-subtitle mb-3">NOVA™ creates content perfect for you.</p>

      <div className="grid grid-cols-2 gap-2.5">
        {aiGeneratedOutputs.map((o) => {
          const Icon = Icons[o.icon] || Icons.FileText
          return (
            <div key={o.key} className="rounded-xl border border-slate-100 p-3">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center mb-2 ${o.color}`}>
                <Icon size={15} />
              </div>
              <p className="text-xs font-semibold text-slate-700 leading-tight">{o.title}</p>
              <p className="text-[10px] text-slate-400 mb-2 leading-tight">{o.desc}</p>
              <button className="text-[11px] font-medium text-primary-500">
                {o.key === 'audio' ? 'Listen' : 'View'}
              </button>
            </div>
          )
        })}
      </div>

      <div className="flex items-center justify-between mt-4 pt-3 border-t border-slate-50">
        <button className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500">
          <Download size={13} /> Download All
        </button>
        <button className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500">
          <Headphones size={13} /> Listen All
        </button>
        <button className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500">
          <Save size={13} /> Save to Library
        </button>
      </div>
    </div>
  )
}
