import { Brain, ThumbsUp, AlertTriangle, Target, Lightbulb } from 'lucide-react'
import ProgressRing from '../common/ProgressRing'
import { conceptCoach as cc } from '../../data/mockData'

export default function ConceptCoach() {
  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-1">
        <span className="w-6 h-6 rounded-lg bg-fuchsia-500 text-white text-xs font-bold flex items-center justify-center">2</span>
        <h3 className="card-title">Concept Coach</h3>
      </div>
      <p className="card-subtitle mb-1">Misconception X-Ray</p>
      <p className="text-[11px] text-slate-400 mb-4">We don't just mark answers. We find the root of misunderstanding.</p>

      <div className="grid md:grid-cols-3 gap-4">
        {/* Quiz */}
        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2 flex items-center gap-1.5">
            <Brain size={14} className="text-fuchsia-500" /> Quiz
          </p>
          <p className="text-xs font-medium text-slate-700 mb-2">{cc.question}</p>
          <div className="flex flex-col gap-1.5">
            {cc.options.map((opt, i) => (
              <label key={opt} className="flex items-center gap-2 text-xs text-slate-600">
                <span
                  className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center ${
                    i === cc.correctIndex ? 'border-emerald-500' : 'border-slate-300'
                  }`}
                >
                  {i === cc.correctIndex && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />}
                </span>
                {opt}
              </label>
            ))}
          </div>
          <p className="text-[11px] text-slate-400 mt-2">
            Your Answer: <span className="font-medium text-slate-600">{cc.yourAnswer}</span>
          </p>
        </div>

        {/* AI Analysis */}
        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2">AI Analysis</p>
          <div className="flex flex-col gap-2">
            <div className="flex items-start gap-2 bg-emerald-50 rounded-lg p-2">
              <ThumbsUp size={13} className="text-emerald-500 mt-0.5 shrink-0" />
              <div>
                <p className="text-[11px] font-semibold text-emerald-700">Strengths</p>
                <p className="text-[10px] text-emerald-700/80">{cc.strengths}</p>
              </div>
            </div>
            <div className="flex items-start gap-2 bg-rose-50 rounded-lg p-2">
              <AlertTriangle size={13} className="text-rose-500 mt-0.5 shrink-0" />
              <div>
                <p className="text-[11px] font-semibold text-rose-700">Common Mistake</p>
                <p className="text-[10px] text-rose-700/80">{cc.commonMistake}</p>
              </div>
            </div>
            <div className="flex items-start gap-2 bg-amber-50 rounded-lg p-2">
              <Target size={13} className="text-amber-500 mt-0.5 shrink-0" />
              <div>
                <p className="text-[11px] font-semibold text-amber-700">Root Cause</p>
                <p className="text-[10px] text-amber-700/80">{cc.rootCause}</p>
              </div>
            </div>
            <div className="flex items-start gap-2 bg-sky-50 rounded-lg p-2">
              <Lightbulb size={13} className="text-sky-500 mt-0.5 shrink-0" />
              <div>
                <p className="text-[11px] font-semibold text-sky-700">Better Explanation</p>
                <p className="text-[10px] text-sky-700/80">{cc.betterExplanation}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Concept Understanding */}
        <div className="flex flex-col items-center">
          <p className="text-xs font-semibold text-slate-600 mb-2 self-start">Concept Understanding</p>
          <ProgressRing percent={cc.understanding.percent} size={90} color="#F59E0B" sublabel={cc.understanding.label} />
          <div className="w-full flex flex-col gap-1.5 mt-3">
            {cc.understanding.bands.map((b) => (
              <div key={b.label} className="flex items-center justify-between text-[10px]">
                <span className="flex items-center gap-1.5 text-slate-500">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: b.color }} />
                  {b.label}
                </span>
                <span className="text-slate-400">{b.range}</span>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-slate-400 mt-2 self-start">
            Recommended Topic: <span className="text-slate-600 font-medium">{cc.recommendedTopic}</span>
          </p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t border-slate-50">
        <button className="text-[11px] font-medium border border-slate-200 rounded-lg px-3 py-1.5 text-slate-600">Explain Again</button>
        <button className="text-[11px] font-medium border border-slate-200 rounded-lg px-3 py-1.5 text-slate-600">Practice More</button>
        <button className="text-[11px] font-medium border border-slate-200 rounded-lg px-3 py-1.5 text-slate-600">Generate Similar Questions</button>
      </div>
    </div>
  )
}
