import { Globe2, Mic2, BookOpen } from 'lucide-react'
import { heroStats } from '../../data/mockData'

export default function HeroBanner() {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary-600 via-primary-500 to-fuchsia-500 text-white p-6 md:p-8 flex flex-col md:flex-row items-center gap-6">
      <div className="flex-1 relative z-10">
        <h2 className="text-2xl md:text-3xl font-extrabold leading-tight mb-1">Learning Without Barriers.</h2>
        <p className="text-white/85 mb-6">AI that adapts to you.</p>

        <div className="flex flex-wrap gap-3">
          {heroStats.map((s) => (
            <div key={s.label} className="bg-white/15 backdrop-blur rounded-xl px-4 py-3 min-w-[110px]">
              <p className="text-lg font-bold leading-tight">{s.value}</p>
              <p className="text-[11px] text-white/80">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="relative w-40 h-40 md:w-48 md:h-48 shrink-0 flex items-center justify-center">
        <div className="absolute inset-0 rounded-full bg-white/10" />
        <BookOpen size={54} className="text-white/90" />
        <Globe2 size={20} className="absolute top-2 left-4 text-white/70" />
        <Mic2 size={20} className="absolute bottom-4 right-2 text-white/70" />
      </div>
    </div>
  )
}
