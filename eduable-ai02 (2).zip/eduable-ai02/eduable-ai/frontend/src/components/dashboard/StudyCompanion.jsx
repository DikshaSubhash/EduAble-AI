import * as Icons from 'lucide-react'
import { Download } from 'lucide-react'
import { studyCompanion as sc } from '../../data/mockData'

export default function StudyCompanion() {
  const progressPct = (sc.todaysGoal.completed / sc.todaysGoal.total) * 100

  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-1">
        <span className="w-6 h-6 rounded-lg bg-primary-500 text-white text-xs font-bold flex items-center justify-center">6</span>
        <h3 className="card-title">AI Study Companion</h3>
      </div>
      <p className="card-subtitle mb-4">Your smart companion for better revision.</p>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        {sc.tools.map((t) => {
          const Icon = Icons[t.icon] || Icons.FileText
          return (
            <div key={t.key} className="rounded-xl border border-slate-100 p-3">
              <Icon size={16} className="text-primary-500 mb-2" />
              <p className="text-xs font-semibold text-slate-700">{t.title}</p>
              <p className="text-[10px] text-slate-400 mb-2">{t.desc}</p>
              <button className="text-[11px] font-medium text-primary-500">View</button>
            </div>
          )
        })}
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2">What's Next?</p>
          <p className="text-[11px] text-slate-500">{sc.whatsNext}</p>
          <button className="text-[11px] font-medium text-primary-500 mt-2">Set Reminder</button>
        </div>

        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2">Quick Actions</p>
          <div className="flex flex-col gap-1.5">
            {sc.quickActions.map((a) => (
              <p key={a} className="text-[11px] text-slate-500">• {a}</p>
            ))}
          </div>
        </div>

        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2">
            Today's Goal <span className="text-slate-400 font-normal">{sc.todaysGoal.completed}/{sc.todaysGoal.total} tasks completed</span>
          </p>
          <div className="w-full bg-slate-100 rounded-full h-1.5 mb-2 overflow-hidden">
            <div className="bg-primary-500 h-1.5 rounded-full" style={{ width: `${progressPct}%` }} />
          </div>
          <div className="flex flex-col gap-1">
            {sc.todaysGoal.tasks.map((t) => (
              <p key={t} className="text-[11px] text-slate-500">• {t}</p>
            ))}
          </div>
        </div>

        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2">Download Center</p>
          <div className="flex flex-col gap-1.5">
            {sc.downloadCenter.map((d) => (
              <button key={d} className="flex items-center gap-1.5 text-[11px] text-slate-500">
                <Download size={12} /> {d}
              </button>
            ))}
          </div>
        </div>
      </div>

      <button className="w-full mt-4 bg-primary-500 hover:bg-primary-600 transition-colors text-white text-sm font-medium rounded-xl py-2.5">
        Download All Study Materials
      </button>
    </div>
  )
}
