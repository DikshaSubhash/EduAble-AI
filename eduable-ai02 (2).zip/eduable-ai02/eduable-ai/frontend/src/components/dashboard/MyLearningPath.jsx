import { CheckCircle2, Circle, ArrowRight } from 'lucide-react'
import { learningPath as lp, currentUser } from '../../data/mockData'

function TimelineItem({ item }) {
  const isDone = item.status === 'done'
  const isNext = item.status === 'next'
  return (
    <div className="flex items-center gap-2.5">
      {isDone ? (
        <CheckCircle2 size={16} className="text-emerald-500 shrink-0" />
      ) : (
        <Circle size={16} className={`shrink-0 ${isNext ? 'text-rose-500' : 'text-slate-300'}`} />
      )}
      <span className={`text-xs ${isNext ? 'font-semibold text-rose-500' : isDone ? 'text-slate-500' : 'text-slate-400'}`}>
        {item.title}
      </span>
      {isNext && <span className="text-[9px] bg-rose-50 text-rose-500 rounded-full px-1.5 py-0.5 ml-auto">Next</span>}
    </div>
  )
}

export default function MyLearningPath() {
  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-1">
        <span className="w-6 h-6 rounded-lg bg-rose-500 text-white text-xs font-bold flex items-center justify-center">5</span>
        <h3 className="card-title">My Learning Path</h3>
      </div>
      <p className="card-subtitle mb-4">AI Learning Journey — your personalized roadmap to mastering the syllabus.</p>

      <div className="grid md:grid-cols-3 gap-4">
        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2">Student Profile</p>
          <div className="flex items-center gap-2 mb-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary-400 to-fuchsia-400 flex items-center justify-center text-white text-xs font-semibold">
              {currentUser.avatarInitials}
            </div>
            <div>
              <p className="text-xs font-semibold text-slate-700">{lp.student.name}</p>
              <p className="text-[10px] text-slate-400">{lp.student.className}</p>
            </div>
          </div>
          <div className="flex flex-col gap-1 text-[11px] text-slate-500">
            <p>Learning Style: <span className="text-slate-700 font-medium">{lp.student.learningStyle}</span></p>
            <p>Focus Level: <span className="text-slate-700 font-medium">{lp.student.focusLevel}</span></p>
            <p>Preferred Language: <span className="text-slate-700 font-medium">{lp.student.preferredLanguage}</span></p>
            <p>Goal: <span className="text-slate-700 font-medium">{lp.student.goal}</span></p>
          </div>
        </div>

        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2">Progress Timeline</p>
          <div className="flex flex-col gap-2.5">
            {lp.timeline.map((t) => (
              <TimelineItem key={t.title} item={t} />
            ))}
          </div>
        </div>

        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2">AI Roadmap</p>
          <div className="flex flex-col gap-1.5 text-[11px] text-slate-500">
            <p>Key Concepts: <span className="text-slate-700 font-medium">{lp.roadmap.keyConcepts}</span></p>
            <p>Revision Needed: <span className="text-slate-700 font-medium">{lp.roadmap.revisionNeeded}</span></p>
            <p>Strong Areas: <span className="text-slate-700 font-medium">{lp.roadmap.strongAreas}</span></p>
            <p>Weak Topics: <span className="text-slate-700 font-medium">{lp.roadmap.weakTopics}</span></p>
            <p>Estimated Study Time: <span className="text-slate-700 font-medium">{lp.roadmap.estimatedStudyTime}</span></p>
            <p>Target Completion Date: <span className="text-slate-700 font-medium">{lp.roadmap.targetCompletionDate}</span></p>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t border-slate-50">
        <button className="flex items-center gap-1.5 text-[11px] font-medium bg-rose-500 text-white rounded-lg px-3 py-1.5">
          Start Next Lesson <ArrowRight size={12} />
        </button>
        <button className="text-[11px] font-medium border border-slate-200 rounded-lg px-3 py-1.5 text-slate-600">Revise</button>
        <button className="text-[11px] font-medium border border-slate-200 rounded-lg px-3 py-1.5 text-slate-600">Generate Practice Test</button>
        <button className="text-[11px] font-medium border border-slate-200 rounded-lg px-3 py-1.5 text-slate-600">Download Roadmap</button>
      </div>
    </div>
  )
}
