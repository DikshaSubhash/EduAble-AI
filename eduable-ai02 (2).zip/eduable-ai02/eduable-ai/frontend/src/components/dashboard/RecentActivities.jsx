import * as Icons from 'lucide-react'
import Card from '../common/Card'
import { recentActivities } from '../../data/mockData'

export default function RecentActivities() {
  return (
    <Card
      title="Recent Activities"
      action={<button className="text-xs font-medium text-primary-500">View All</button>}
    >
      <div className="flex flex-col divide-y divide-slate-50">
        {recentActivities.map((a) => {
          const Icon = Icons[a.icon] || Icons.FileText
          return (
            <div key={a.id} className="flex items-center gap-3 py-2.5 first:pt-0 last:pb-0">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${a.color}`}>
                <Icon size={16} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-slate-700 truncate">{a.title}</p>
                <p className="text-[11px] text-slate-400 truncate">{a.subtitle}</p>
              </div>
              <span className="text-[11px] text-slate-400 shrink-0">{a.time}</span>
            </div>
          )
        })}
      </div>
    </Card>
  )
}
