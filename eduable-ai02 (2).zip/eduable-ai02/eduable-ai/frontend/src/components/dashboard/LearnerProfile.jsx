import { useState } from 'react'
import * as Icons from 'lucide-react'
import { Check } from 'lucide-react'
import { learnerProfileOptions } from '../../data/mockData'

export default function LearnerProfile() {
  const [active, setActive] = useState(learnerProfileOptions.find((o) => o.active)?.key || learnerProfileOptions[0].key)

  return (
    <div className="card">
      <h3 className="card-title">Learner Profile</h3>
      <p className="card-subtitle mb-3">Select the profile that fits you best.</p>

      <div className="flex flex-col gap-1.5">
        {learnerProfileOptions.map((o) => {
          const Icon = Icons[o.icon] || Icons.Circle
          const isActive = active === o.key
          return (
            <button
              key={o.key}
              onClick={() => setActive(o.key)}
              className={`flex items-center justify-between px-3 py-2 rounded-xl text-sm transition-colors ${
                isActive ? 'bg-primary-50 text-primary-600' : 'text-slate-600 hover:bg-slate-50'
              }`}
            >
              <span className="flex items-center gap-2.5">
                <Icon size={16} className={isActive ? 'text-primary-500' : 'text-slate-400'} />
                {o.label}
              </span>
              {isActive && (
                <span className="w-4 h-4 rounded-full bg-primary-500 flex items-center justify-center">
                  <Check size={10} className="text-white" />
                </span>
              )}
            </button>
          )
        })}
      </div>
    </div>
  )
}
