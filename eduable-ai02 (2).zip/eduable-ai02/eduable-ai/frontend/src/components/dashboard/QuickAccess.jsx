import * as Icons from 'lucide-react'
import { ArrowRight } from 'lucide-react'
import { Link } from 'react-router-dom'
import { quickAccessModules } from '../../data/mockData'

export default function QuickAccess() {
  return (
    <div>
      <h3 className="text-sm font-semibold text-slate-700 mb-3">Quick Access to EduAble AI Modules</h3>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {quickAccessModules.map((m) => {
          const Icon = Icons[m.icon] || Icons.Circle
          return (
            <Link key={m.id} to={m.path} className="card !p-4 flex flex-col justify-between hover:shadow-soft transition-shadow">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[10px] font-semibold text-slate-400">{m.id}</span>
                  <div className={`w-8 h-8 rounded-lg ${m.color} text-white flex items-center justify-center`}>
                    <Icon size={16} />
                  </div>
                </div>
                <p className="text-sm font-semibold text-slate-800 leading-tight">{m.title}</p>
                <p className="text-[11px] text-slate-400 mb-2">{m.desc}</p>
                <p className="text-[11px] text-slate-500 leading-snug">{m.text}</p>
              </div>
              <span className="mt-3 self-start w-7 h-7 rounded-full bg-primary-500 text-white flex items-center justify-center">
                <ArrowRight size={14} />
              </span>
            </Link>
          )
        })}
      </div>
    </div>
  )
}
