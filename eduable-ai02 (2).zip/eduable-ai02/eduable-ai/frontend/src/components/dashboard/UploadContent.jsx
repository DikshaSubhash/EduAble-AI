import { useState } from 'react'
import { UploadCloud, FileText, X } from 'lucide-react'

const TABS = ['Upload PDF', 'Upload Image', 'Paste Text']

export default function UploadContent() {
  const [activeTab, setActiveTab] = useState('Upload PDF')
  const [file, setFile] = useState({ name: 'Class_10_Physics_Chapter2.pdf', size: '2.4 MB' })

  return (
    <div className="card">
      <h3 className="card-title mb-3">Upload Content</h3>

      <div className="flex bg-slate-50 rounded-xl p-1 mb-4">
        {TABS.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 text-[11px] font-medium py-1.5 rounded-lg transition-colors ${
              activeTab === tab ? 'bg-white shadow-card text-primary-600' : 'text-slate-400'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      <label className="flex flex-col items-center justify-center gap-2 border-2 border-dashed border-primary-200 bg-primary-50/40 rounded-xl py-8 cursor-pointer">
        <input
          type="file"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0]
            if (f) setFile({ name: f.name, size: `${(f.size / (1024 * 1024)).toFixed(1)} MB` })
          }}
        />
        <UploadCloud className="text-primary-400" size={26} />
        <p className="text-xs text-slate-500 text-center">
          <span className="text-primary-500 font-medium">Drag & drop your file here</span>
          <br />
          or click to browse
        </p>
        <p className="text-[10px] text-slate-400">Supports: PDF, PPT, JPG, PNG, DOCX, TXT (Max 50MB)</p>
      </label>

      {file && (
        <div className="flex items-center justify-between bg-slate-50 rounded-xl px-3 py-2 mt-3">
          <div className="flex items-center gap-2 min-w-0">
            <FileText size={16} className="text-rose-500 shrink-0" />
            <div className="min-w-0">
              <p className="text-xs font-medium text-slate-700 truncate">{file.name}</p>
              <p className="text-[10px] text-slate-400">{file.size}</p>
            </div>
          </div>
          <button onClick={() => setFile(null)}>
            <X size={14} className="text-slate-400" />
          </button>
        </div>
      )}

      <button className="w-full mt-4 bg-primary-500 hover:bg-primary-600 transition-colors text-white text-sm font-medium rounded-xl py-2.5">
        Process with NOVA™
      </button>
    </div>
  )
}
