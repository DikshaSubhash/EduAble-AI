import { useState } from 'react'
import * as Icons from 'lucide-react'
import { worldChoices, myWorldExplanation } from '../../data/mockData'

export default function MyWorld() {
  const [active, setActive] = useState(worldChoices.find((w) => w.active)?.key || worldChoices[0].key)

  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-1">
        <span className="w-6 h-6 rounded-lg bg-amber-500 text-white text-xs font-bold flex items-center justify-center">3</span>
        <h3 className="card-title">My World</h3>
      </div>
      <p className="card-subtitle mb-4">LifeLens Learning — learn through real-life examples from the world you love.</p>

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2">Choose Your World</p>
          <div className="flex flex-col gap-1">
            {worldChoices.map((w) => {
              const Icon = Icons[w.icon] || Icons.Circle
              const isActive = active === w.key
              return (
                <button
                  key={w.key}
                  onClick={() => setActive(w.key)}
                  className={`flex items-center justify-between px-3 py-2 rounded-xl text-sm transition-colors ${
                    isActive ? 'bg-amber-50 text-amber-600' : 'text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <span className="flex items-center gap-2.5">
                    <Icon size={16} className={isActive ? 'text-amber-500' : 'text-slate-400'} />
                    {w.label}
                  </span>
                  {isActive && <span className="w-2 h-2 rounded-full bg-amber-500" />}
                </button>
              )
            })}
          </div>
        </div>

        <div className="rounded-xl bg-amber-50/60 p-4">
          <p className="text-[11px] text-slate-400 mb-1">Original Concept</p>
          <p className="text-sm font-semibold text-slate-800 mb-3">{myWorldExplanation.originalConcept}</p>

          <p className="text-[11px] text-slate-400 mb-1">Explained in Your World</p>
          <p className="text-sm font-semibold text-amber-600 mb-2">{myWorldExplanation.exampleTitle}</p>
          <p className="text-xs text-slate-600 leading-relaxed">{myWorldExplanation.text}</p>

          <div className="flex gap-2 mt-4">
            <button className="text-[11px] font-medium border border-amber-200 rounded-lg px-3 py-1.5 text-amber-600 bg-white">
              Explain Another Way
            </button>
            <button className="text-[11px] font-medium border border-amber-200 rounded-lg px-3 py-1.5 text-amber-600 bg-white">
              Change Perspective
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
