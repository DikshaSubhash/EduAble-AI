import { FileText, CheckCircle2 } from 'lucide-react'
import ProgressRing from '../common/ProgressRing'
import ProgressBar from '../common/ProgressBar'
import { accessibilityReport as report } from '../../data/mockData'

export default function AccessCheck() {
  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-1">
        <span className="w-6 h-6 rounded-lg bg-sky-500 text-white text-xs font-bold flex items-center justify-center">4</span>
        <h3 className="card-title">Access Check</h3>
      </div>
      <p className="card-subtitle mb-4">Accessibility Intelligence Score — see how accessible and inclusive your content is.</p>

      <div className="grid md:grid-cols-3 gap-4">
        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2">Upload Checked</p>
          <div className="flex items-center gap-2 bg-slate-50 rounded-lg p-2.5">
            <FileText size={16} className="text-rose-500" />
            <div>
              <p className="text-xs font-medium text-slate-700">{report.fileName}</p>
              <p className="text-[10px] text-slate-400">{report.fileSize}</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-center">
          <p className="text-xs font-semibold text-slate-600 mb-2 self-start">Accessibility Report</p>
          <ProgressRing percent={(report.score / report.maxScore) * 100} label={`${report.score}`} sublabel={`/${report.maxScore}`} size={92} color="#3B82F6" />
          <p className="text-[11px] font-medium text-sky-600 mt-2">{report.label}</p>
          <div className="w-full flex flex-col gap-2 mt-3">
            {report.metrics.map((m) => (
              <div key={m.label}>
                <div className="flex items-center justify-between text-[10px] text-slate-500 mb-0.5">
                  <span>{m.label}</span>
                  <span>{m.value}/100</span>
                </div>
                <ProgressBar value={m.value} color="bg-sky-500" />
              </div>
            ))}
          </div>
        </div>

        <div>
          <p className="text-xs font-semibold text-slate-600 mb-2">Suggestions</p>
          <div className="flex flex-col gap-2">
            {report.suggestions.map((s) => (
              <div key={s} className="flex items-start gap-2 text-[11px] text-slate-600">
                <CheckCircle2 size={13} className="text-emerald-500 mt-0.5 shrink-0" />
                {s}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="flex gap-2 mt-4 pt-3 border-t border-slate-50">
        <button className="text-[11px] font-medium border border-slate-200 rounded-lg px-3 py-1.5 text-slate-600">Improve Document</button>
        <button className="text-[11px] font-medium border border-slate-200 rounded-lg px-3 py-1.5 text-slate-600">Download Report</button>
      </div>
    </div>
  )
}
