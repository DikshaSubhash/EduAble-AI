import Card from '../common/Card'
import ProgressRing from '../common/ProgressRing'
import { learningInsightStats, understandingOverview } from '../../data/mockData'

export default function LearningInsights() {
  return (
    <Card
      title="Learning Insights"
      action={<button className="text-xs font-medium text-slate-400">This Week ▾</button>}
    >
      <div className="grid grid-cols-3 gap-3 mb-5">
        {learningInsightStats.map((s) => (
          <div key={s.label}>
            <p className="text-[11px] text-slate-400 mb-1">{s.label}</p>
            <p className="text-lg font-bold text-slate-800">{s.value}</p>
            <p className="text-[10px] text-emerald-500">↑ {s.delta}</p>
          </div>
        ))}
      </div>

      <div className="border-t border-slate-50 pt-4">
        <p className="text-xs font-semibold text-slate-600 mb-3">Understanding Overview</p>
        <div className="flex items-center gap-5">
          <ProgressRing percent={understandingOverview.percent} size={92} color="#6C4DF6" />
          <div className="flex-1 flex flex-col gap-2">
            {understandingOverview.breakdown.map((b) => (
              <div key={b.label} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-2 text-slate-500">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: b.color }} />
                  {b.label}
                </span>
                <span className="font-medium text-slate-700">{b.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Card>
  )
}
