import novaEngine from "../nova/novaEngine.js";

export async function learnEasy(req, res) {

    try {

        const result =
            await novaEngine.execute({

                userId: req.user.id,

                module: "learnEasy",

                query: req.body.query,

                uploadedText: req.body.content,

                preferences: req.body.preferences

            });

        res.json(result);

    } catch (error) {

        res.status(500).json({

            success: false,

            message: error.message

        });

    }

}