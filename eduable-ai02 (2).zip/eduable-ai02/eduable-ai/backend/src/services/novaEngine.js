import { buildContext } from "./contextManager.js";
import { buildPrompt } from "./promptOrchestrator.js";
import gemmaService from "../services/gemmaService.js";
import { validateOutput } from "./outputValidator.js";

class NOVAEngine {

    async execute(request) {

        //-------------------------------------------------------
        // STEP 1
        //-------------------------------------------------------

        const context =
            await buildContext(request);

        //-------------------------------------------------------
        // STEP 2
        //-------------------------------------------------------

        const prompt =
            buildPrompt(context);

        //-------------------------------------------------------
        // STEP 3
        //-------------------------------------------------------

        const aiResponse =
            await gemmaService.generate(prompt);

        //-------------------------------------------------------
        // STEP 4
        //-------------------------------------------------------

        const validated =
            validateOutput(aiResponse);

        //-------------------------------------------------------
        // STEP 5
        //-------------------------------------------------------

        return {

            success: true,

            context,

            response: validated

        };

    }

}

export default new NOVAEngine();