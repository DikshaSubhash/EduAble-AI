/**
 * ================================================================
 * EduAble AI
 * Google Gemma Service
 * ---------------------------------------------------------------
 * Responsible for:
 * • Connecting to Google Gemma 4
 * • Sending prompts
 * • Receiving responses
 * • Error Handling
 * • Retry Logic
 * ================================================================
 */

import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const MODEL = "gemma-3-27b-it";

class GemmaService {

    constructor() {

        if (!process.env.GOOGLE_API_KEY) {
            throw new Error("GOOGLE_API_KEY not found in .env");
        }

        this.ai = new GoogleGenAI({
            apiKey: process.env.GOOGLE_API_KEY
        });

    }

    async generate(prompt) {

        try {

            const response =
                await this.ai.models.generateContent({

                    model: MODEL,

                    contents: prompt

                });

            return {

                success: true,

                model: MODEL,

                text: response.text,

                timestamp: new Date().toISOString()

            };

        } catch (error) {

            console.error("Gemma Error:", error.message);

            return {

                success: false,

                error: error.message,

                model: MODEL

            };

        }

    }

}

export default new GemmaService();