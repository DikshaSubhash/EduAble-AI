/**
 * ============================================================
 * EduAble AI
 * NOVA Prompt Intelligence Engine
 * ============================================================
 *
 * Creates the FINAL prompt that is sent to Google Gemma.
 *
 */

import { buildInstructions } from "./instructionEngine.js";
import { buildContextBlock } from "./contextBuilder.js";
import { buildObjective } from "./objectiveEngine.js";
import { buildResponseSchema } from "./responseSchema.js";

export function createPrompt(context) {

    const instructions =
        buildInstructions(context.module);

    const learnerContext =
        buildContextBlock(context);

    const objective =
        buildObjective(context.module);

    const schema =
        buildResponseSchema(context.module);

    return `

${instructions}

${objective}

${learnerContext}

User Question

${context.query}

Educational Content

${context.uploadedText}

${schema}

`;

}