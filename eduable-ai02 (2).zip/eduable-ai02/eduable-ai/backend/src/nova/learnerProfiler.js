/**
 * ============================================================
 * Learner Profiler
 * ============================================================
 */

export function buildLearnerProfile(preferences = {}) {

    return {

        learningStyle:
            preferences.learningStyle || "Visual",

        language:
            preferences.language || "English",

        gradeLevel:
            preferences.gradeLevel || "General",

        readingLevel:
            preferences.readingLevel || "Intermediate",

        accessibility:
            preferences.accessibility || "None",

        interests:
            preferences.interests || [],

        previousTopics:
            preferences.previousTopics || []
    };

}