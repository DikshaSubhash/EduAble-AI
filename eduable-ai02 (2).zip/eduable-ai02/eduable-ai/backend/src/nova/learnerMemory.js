/**
 * Learner Memory
 */

export function buildMemory(session) {

    return {

        previousQuestions:

            session.history.map(x => x.question),

        previousResponses:

            session.history.map(x => x.answer),

        completedTopics:

            session.completedTopics,

        weakTopics:

            session.weakTopics,

        recommendations:

            session.recommendations

    };

}