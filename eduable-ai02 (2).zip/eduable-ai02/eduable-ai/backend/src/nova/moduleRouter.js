/**
 * ============================================================
 * Module Router
 * ============================================================
 */

import { MODULE_REGISTRY } from "./moduleRegistry.js";
import { formatResponse } from "./responseFormatter.js";

export function route(module, aiResponse) {

    const config = MODULE_REGISTRY[module];

    if (!config) {

        throw new Error("Unknown EduAble AI module.");

    }

    return formatResponse(config.name, aiResponse);

}