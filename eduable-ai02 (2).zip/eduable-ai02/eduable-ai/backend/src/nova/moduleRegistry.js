/**
 * ============================================================
 * EduAble AI
 * Module Registry
 * ============================================================
 */

export const MODULE_REGISTRY = {

    learnEasy: {

        name: "LearnEasy",

        formatter: "learnEasyFormatter"

    },

    conceptCoach: {

        name: "Concept Coach",

        formatter: "conceptCoachFormatter"

    },

    myWorld: {

        name: "My World",

        formatter: "myWorldFormatter"

    },

    accessCheck: {

        name: "Access Check",

        formatter: "accessFormatter"

    },

    learningPath: {

        name: "My Learning Path",

        formatter: "roadmapFormatter"

    },

    studyCompanion: {

        name: "AI Study Companion",

        formatter: "studyFormatter"

    }

};