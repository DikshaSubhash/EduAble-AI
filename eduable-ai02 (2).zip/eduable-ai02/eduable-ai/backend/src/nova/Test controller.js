const result = await execute({

    userId: "student01",

    module: "learnEasy",

    query: "Explain Machine Learning",

    uploadedText: "",

    preferences: {

        learningStyle: "Visual",

        language: "English"

    }

});

console.log(result.prompt);