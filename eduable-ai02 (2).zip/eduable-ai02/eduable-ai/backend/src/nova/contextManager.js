/**
 * ============================================================
 * EduAble AI
 * NOVA Cognitive Engine
 * Context Manager
 * ------------------------------------------------------------
 * Builds a unified context object for every AI request.
 * ============================================================
 */

import { buildLearnerProfile } from "./learnerProfiler.js";
import sessionManager from "./sessionManager.js";
import { buildMemory } from "./learnerMemory.js";

export async function buildContext(request) {
    const {
        userId,
        module,
        query,
        uploadedText = "",
        metadata = {},
        session = {},
        preferences = {}
    } = request;

    // Generate learner profile
    const learnerProfile = buildLearnerProfile(preferences);

    return {
        requestId: crypto.randomUUID(),

        timestamp: new Date().toISOString(),

        userId,

        module,

        query,

        uploadedText,

        metadata,

        learnerProfile,

        session,

        system: {
            platform: "EduAble AI",
            engine: "NOVA Cognitive Engine",
            model: "Google Gemma 4"
        }
    };
}