import { buildContext } from "./contextManager.js";
import { buildPrompt } from "./promptOrchestrator.js";

export async function execute(request){

    const context = await buildContext(request);

    const prompt = buildPrompt(context);

   import { route } from "./moduleRouter.js";

const formatted = route(

    context.module,

    validated

);

return formatted;

}