# EduAble AI — Backend (empty structure)

This folder is intentionally left empty of code — only the intended structure
is scaffolded (as requested). Build the backend here later, e.g. with
Node.js/Express + MongoDB or PostgreSQL, matching the endpoints already
referenced in `frontend/src/utils/api.js`.

## Suggested folder structure

```
backend/
├─ src/
│  ├─ config/        # DB connection, env config, third-party (Google Gemma / NOVA) keys
│  ├─ controllers/   # request handlers (auth, content, conceptCoach, myWorld, accessCheck, learningPath, studyCompanion, insights)
│  ├─ models/        # DB schemas (User, Content, Quiz, LearningPath, ...)
│  ├─ routes/        # Express routers, one file per resource
│  ├─ middleware/    # auth guard, error handler, file upload (multer), rate limiter
│  ├─ services/      # business logic, AI/NOVA integration, PDF/text processing
│  ├─ utils/         # helpers (logger, response formatter, etc.)
│  └─ validators/    # request payload validation schemas
├─ uploads/           # uploaded PDFs/images (gitignored in real use)
└─ tests/             # unit/integration tests
```

## Suggested endpoints (already stubbed on the frontend)

| Method | Route                                   | Purpose                                  |
|--------|------------------------------------------|-------------------------------------------|
| POST   | /api/auth/register                       | create account                            |
| POST   | /api/auth/login                          | login, issue JWT                          |
| GET    | /api/auth/me                             | current user profile                      |
| POST   | /api/content/upload                      | upload PDF/image/text                     |
| POST   | /api/content/:id/process                 | run NOVA processing for a learner profile |
| GET    | /api/concept-coach/quiz/:topicId         | fetch a misconception-check quiz          |
| POST   | /api/concept-coach/quiz/:quizId/answer   | submit an answer, get AI analysis         |
| GET    | /api/my-world/:conceptId                 | get concept explained via chosen "world"  |
| POST   | /api/access-check/:contentId/analyze     | run accessibility scoring                 |
| GET    | /api/learning-path/:studentId            | get personalized learning path            |
| GET    | /api/study-companion/flashcards/:topicId | fetch flashcards                          |
| POST   | /api/study-companion/quiz/:topicId       | generate a practice quiz                  |
| GET    | /api/insights/:studentId                 | learning insights summary                 |

Add `.env`, `package.json`, and source files here when backend development starts.
