import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { LearnEasyTutor } from './components/LearnEasyTutor';
import { RAGKnowledgeHub } from './components/RAGKnowledgeHub';
import { NOVAPipelineVisualizer } from './components/NOVAPipelineVisualizer';
import { AdaptiveQuiz } from './components/AdaptiveQuiz';
import { LearnerProfileSettings } from './components/LearnerProfileSettings';
import { SessionAnalytics } from './components/SessionAnalytics';
import { LearnerProfile, NOVAResponse } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('learn');
  const [learnerProfile, setLearnerProfile] = useState<LearnerProfile | null>(null);
  const [dyslexiaFontEnabled, setDyslexiaFontEnabled] = useState<boolean>(false);
  const [lastNovaResponse, setLastNovaResponse] = useState<NOVAResponse | null>(null);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const res = await fetch('/api/learner/profile?userId=default_student');
      if (res.ok) {
        const data = await res.json();
        setLearnerProfile(data.profile);
      }
    } catch (err) {
      console.error('Failed to fetch profile:', err);
    }
  };

  const handleUpdateProfile = async (updatedData: Partial<LearnerProfile>) => {
    try {
      const res = await fetch('/api/learner/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: 'default_student',
          ...updatedData,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setLearnerProfile(data.profile);
      }
    } catch (err) {
      console.error('Failed to update profile:', err);
    }
  };

  const handleViewPipeline = (response: NOVAResponse) => {
    setLastNovaResponse(response);
    setActiveTab('nova');
  };

  const defaultProfile: LearnerProfile = learnerProfile || {
    userId: 'default_student',
    name: 'Alex Johnson',
    email: 'alex.johnson@eduable.ai',
    learningStyle: 'adhd_chunked',
    readingLevel: 'high_school',
    accessibility: ['short_paragraphs', 'dyslexia_font'],
    language: 'English',
    interests: ['AI', 'Biotechnology', 'Space'],
    weakTopics: ['Vector Space Math', 'Gradient Descent'],
    completedTopics: ['Intro to Machine Learning'],
    careerGoal: 'AI Software Engineer & Accessibility Advocate',
  };

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans ${dyslexiaFontEnabled ? 'font-dyslexia' : ''}`}>
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        learnerProfile={defaultProfile}
        dyslexiaFontEnabled={dyslexiaFontEnabled}
        setDyslexiaFontEnabled={setDyslexiaFontEnabled}
      />

      {/* Main Content View Container */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
        {activeTab === 'learn' && (
          <LearnEasyTutor
            learnerProfile={defaultProfile}
            onUpdateProfile={handleUpdateProfile}
            onViewPipeline={handleViewPipeline}
          />
        )}

        {activeTab === 'rag' && (
          <RAGKnowledgeHub
            userId={defaultProfile.userId}
            onSelectTopicForTutor={(topicPrompt) => {
              setActiveTab('learn');
            }}
          />
        )}

        {activeTab === 'nova' && (
          <NOVAPipelineVisualizer lastResponse={lastNovaResponse} />
        )}

        {activeTab === 'quiz' && (
          <AdaptiveQuiz userId={defaultProfile.userId} />
        )}

        {activeTab === 'analytics' && (
          <SessionAnalytics userId={defaultProfile.userId} />
        )}

        {activeTab === 'profile' && (
          <LearnerProfileSettings
            profile={defaultProfile}
            onUpdateProfile={handleUpdateProfile}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900/80 border-t border-slate-800 py-4 px-6 text-center text-xs text-slate-500">
        EduAble AI — Adaptive Accessibility & RAG Learning Platform • Powered by NOVA Orchestrator & Gemma
      </footer>
    </div>
  );
}
