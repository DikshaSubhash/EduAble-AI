export interface LearnerProfile {
  userId: string;
  name?: string;
  email?: string;
  learningStyle: 'visual' | 'auditory' | 'kinesthetic' | 'reading_writing' | 'adhd_chunked' | 'dyslexia_friendly';
  readingLevel: 'elementary' | 'middle_school' | 'high_school' | 'college' | 'expert';
  accessibility: string[];
  language: string;
  interests: string[];
  weakTopics: string[];
  completedTopics: string[];
  careerGoal?: string;
}

export interface NOVAStageTrace {
  stageName: string;
  startTime: number;
  endTime: number;
  durationMs: number;
  status: 'pending' | 'success' | 'failed';
  dataSnapshot?: any;
}

export interface EvaluationReport {
  overallScore: number;
  readabilityGrade: string;
  readabilityScore: number;
  factualityConfidence: number;
  toneAppropriateness: number;
  accessibilityCompliance: number;
  feedback: string[];
}

export interface NOVAResponse {
  answer: string;
  evaluation: EvaluationReport;
  traceLogs: NOVAStageTrace[];
  retrievedContext: Array<{
    id: string;
    text: string;
    score: number;
    metadata?: any;
  }>;
  guardedResponse: {
    passed: boolean;
    safetyScore: number;
    violations: string[];
    response: {
      text: string;
      hasKeyTakeaway: boolean;
      hasSelfCheck: boolean;
    };
  };
  sessionId?: string;
}

export interface IndexedDocumentRecord {
  id: string;
  userId: string;
  title: string;
  fileType: string;
  chunkCount: number;
  pages?: number;
  uploadedAt: string;
  summary?: string;
}

export interface LearningSession {
  id: string;
  userId: string;
  module: 'learn_easy' | 'concept_coach' | 'rag_query' | 'adaptive_quiz';
  query: string;
  response: string;
  evaluation?: EvaluationReport;
  createdAt: string;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
  topicTag: string;
}

export interface QuizAttempt {
  id: string;
  userId: string;
  topic: string;
  score: number;
  totalQuestions: number;
  userAnswers: number[];
  questions: QuizQuestion[];
  evaluationFeedback: string;
  completedAt: string;
}
