import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "";

const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

const MODEL = "text-embedding-004";

export interface VectorChunk {
  id: string;
  text: string;
  embedding: number[];
  metadata?: Record<string, any>;
}

class EmbeddingService {
  /**
   * Generates a vector embedding for a single text block.
   */
  async create(text: string): Promise<number[]> {
    if (!text || !text.trim()) {
      throw new Error("Embedding text cannot be empty.");
    }

    try {
      if (apiKey) {
        const response: any = await ai.models.embedContent({
          model: MODEL,
          contents: text,
        });

        const embeddingValues = response?.embedding?.values || response?.embeddings?.[0]?.values;
        if (embeddingValues && Array.isArray(embeddingValues)) {
          return embeddingValues;
        }
      }
    } catch (error) {
      console.warn("API embedding failed, using deterministic pseudo-embedding fallback:", error);
    }

    // Deterministic fallback embedding generation (vector size 768) if key/quota unavailable
    return this.generatePseudoEmbedding(text);
  }

  /**
   * Batches embedding generation across document chunks.
   */
  async createBatch(chunks: { id: string; text: string; metadata?: Record<string, any> }[] = []): Promise<VectorChunk[]> {
    const vectors: VectorChunk[] = [];

    for (const chunk of chunks) {
      const embedding = await this.create(chunk.text);
      vectors.push({
        id: chunk.id,
        text: chunk.text,
        embedding,
        metadata: chunk.metadata,
      });
    }

    return vectors;
  }

  private generatePseudoEmbedding(text: string): number[] {
    const dimensions = 768;
    const vec = new Array(dimensions).fill(0);
    const words = text.toLowerCase().split(/\s+/);

    for (let i = 0; i < words.length; i++) {
      const word = words[i];
      for (let j = 0; j < word.length; j++) {
        const charCode = word.charCodeAt(j);
        const idx = (charCode * (i + 1) * (j + 13)) % dimensions;
        vec[idx] += (charCode / 255.0);
      }
    }

    // Normalize vector
    const norm = Math.sqrt(vec.reduce((sum, val) => sum + val * val, 0)) || 1;
    return vec.map((val) => val / norm);
  }
}

export default new EmbeddingService();
