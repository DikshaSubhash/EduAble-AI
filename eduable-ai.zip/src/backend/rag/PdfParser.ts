import * as pdfParseModule from "pdf-parse";

const pdfParse = (pdfParseModule as any).default || pdfParseModule;

export class PdfParser {
  /**
   * Parses text from a PDF Buffer or plain text Buffer.
   */
  async parseBuffer(buffer: Buffer, mimeType?: string, fileName?: string): Promise<{ text: string; numPages: number; info?: any }> {
    if (mimeType === "application/pdf" || fileName?.endsWith(".pdf")) {
      try {
        const parsed = await pdfParse(buffer);
        return {
          text: parsed.text || "",
          numPages: parsed.numpages || 1,
          info: parsed.info || {},
        };
      } catch (err) {
        console.warn("pdf-parse error, falling back to raw text extraction:", err);
        const rawText = buffer.toString("utf-8").replace(/[^\x20-\x7E\n\r\t]/g, " ");
        return { text: rawText, numPages: 1 };
      }
    }

    // Default plain text / markdown / JSON file
    const text = buffer.toString("utf-8");
    const estimatedPages = Math.ceil(text.length / 2000) || 1;
    return {
      text,
      numPages: estimatedPages,
    };
  }
}

export default new PdfParser();
