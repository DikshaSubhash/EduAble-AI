export interface StoredDocument {
  id: string;
  embedding: number[];
  text: string;
  metadata?: Record<string, any>;
}

export interface SearchResult {
  id: string;
  text: string;
  score: number;
  metadata?: Record<string, any>;
}

class VectorStore {
  private documents: Map<string, StoredDocument> = new Map();

  async initialize() {
    // Vector store initialized
    return true;
  }

  async store(id: string, embedding: number[], text: string, metadata?: Record<string, any>) {
    await this.initialize();
    this.documents.set(id, {
      id,
      embedding,
      text,
      metadata,
    });
  }

  async search(queryEmbedding: number[], limit = 5): Promise<SearchResult[]> {
    await this.initialize();

    if (this.documents.size === 0) {
      return [];
    }

    const results: SearchResult[] = [];

    for (const doc of this.documents.values()) {
      const score = this.cosineSimilarity(queryEmbedding, doc.embedding);
      results.push({
        id: doc.id,
        text: doc.text,
        score,
        metadata: doc.metadata,
      });
    }

    results.sort((a, b) => b.score - a.score);
    return results.slice(0, limit);
  }

  async listDocuments(): Promise<StoredDocument[]> {
    return Array.from(this.documents.values());
  }

  async clear() {
    this.documents.clear();
  }

  private cosineSimilarity(vecA: number[], vecB: number[]): number {
    if (!vecA || !vecB || vecA.length !== vecB.length) return 0;
    let dot = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < vecA.length; i++) {
      dot += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }
    if (normA === 0 || normB === 0) return 0;
    return dot / (Math.sqrt(normA) * Math.sqrt(normB));
  }
}

export default new VectorStore();
