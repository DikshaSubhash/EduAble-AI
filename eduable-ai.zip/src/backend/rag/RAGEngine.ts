import embeddingService from "./EmbeddingService.js";
import vectorStore, { SearchResult } from "./VectorStore.js";
import pdfParser from "./PdfParser.js";

export interface DocumentPayload {
  id?: string;
  title: string;
  content?: string;
  buffer?: Buffer;
  mimeType?: string;
}

export class RAGEngine {
  /**
   * Splits a document into overlapping semantic chunks for indexing.
   */
  chunkDocument(text: string, chunkSize = 500, overlap = 100): { id: string; text: string }[] {
    if (!text) return [];

    const cleanText = text.replace(/\s+/g, " ").trim();
    const words = cleanText.split(" ");
    const chunks: { id: string; text: string }[] = [];

    let start = 0;
    let chunkIndex = 0;

    while (start < words.length) {
      const end = Math.min(start + chunkSize, words.length);
      const chunkText = words.slice(start, end).join(" ");

      chunks.push({
        id: `chunk_${Date.now()}_${chunkIndex++}`,
        text: chunkText,
      });

      start += (chunkSize - overlap);
      if (start >= words.length || chunkSize <= overlap) break;
    }

    return chunks;
  }

  /**
   * Indexes a document: parses PDF/text, chunks, computes embeddings, and stores in VectorStore.
   */
  async indexDocument(document: DocumentPayload) {
    let rawText = document.content || "";
    let pageCount = 1;

    if (document.buffer) {
      const parsed = await pdfParser.parseBuffer(document.buffer, document.mimeType, document.title);
      rawText = parsed.text;
      pageCount = parsed.numPages;
    }

    if (!rawText.trim()) {
      throw new Error("Document content is empty.");
    }

    const docId = document.id || `doc_${Date.now()}`;
    const chunks = this.chunkDocument(rawText);

    const chunkPayloads = chunks.map((chunk, idx) => ({
      id: `${docId}_${idx}`,
      text: chunk.text,
      metadata: {
        docId,
        docTitle: document.title,
        chunkIndex: idx,
        totalChunks: chunks.length,
        pages: pageCount,
      },
    }));

    const vectors = await embeddingService.createBatch(chunkPayloads);

    for (const vector of vectors) {
      await vectorStore.store(vector.id, vector.embedding, vector.text, vector.metadata);
    }

    return {
      docId,
      title: document.title,
      indexedChunks: vectors.length,
      pages: pageCount,
    };
  }

  /**
   * Retrieves relevant context chunks based on semantic search query.
   */
  async retrieve(query: string, limit = 4): Promise<SearchResult[]> {
    if (!query || !query.trim()) return [];

    const queryEmbedding = await embeddingService.create(query);
    const results = await vectorStore.search(queryEmbedding, limit);
    return results;
  }
}

export default new RAGEngine();
