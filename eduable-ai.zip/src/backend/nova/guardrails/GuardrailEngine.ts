export interface GuardrailResult {
  passed: boolean;
  sanitizedResponse: string;
  violations: string[];
  safetyScore: number;
  response: {
    text: string;
    hasKeyTakeaway: boolean;
    hasSelfCheck: boolean;
  };
}

export function applyGuardrails(request: any, rawResponseText: string): GuardrailResult {
  const violations: string[] = [];
  let text = rawResponseText || "";
  let safetyScore = 1.0;

  // Basic toxicity / inappropriate word check
  const prohibitedPatterns = [/toxic_word_placeholder/i, /unsafe_code_injection/i];
  for (const pattern of prohibitedPatterns) {
    if (pattern.test(text)) {
      violations.push(`Detected potentially unsafe content matching rule ${pattern}`);
      text = text.replace(pattern, "[Filtered]");
      safetyScore -= 0.3;
    }
  }

  // Ensure response isn't empty or truncated
  if (!text.trim() || text.length < 10) {
    violations.push("Response is too short or empty.");
    text = "I'm sorry, I couldn't generate a complete answer. Let me re-explain this topic simply for you.";
    safetyScore -= 0.5;
  }

  // Check structural guardrails
  const hasKeyTakeaway = /Key Takeaway|Summary|Quick Summary/i.test(text);
  const hasSelfCheck = /Self-Check|Quiz|Question|Check your understanding/i.test(text);

  if (!hasKeyTakeaway) {
    text += "\n\n**💡 Key Takeaway:** Understanding core concepts step-by-step builds long-term knowledge retention.";
  }

  return {
    passed: violations.length === 0,
    sanitizedResponse: text,
    violations,
    safetyScore: Math.max(0, safetyScore),
    response: {
      text,
      hasKeyTakeaway: true,
      hasSelfCheck,
    },
  };
}
