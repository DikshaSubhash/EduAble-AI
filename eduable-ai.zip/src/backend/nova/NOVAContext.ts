import { LearnerProfile } from "../database/models/Learner.js";

export interface NOVAStageTrace {
  stageName: string;
  startTime: number;
  endTime: number;
  durationMs: number;
  status: 'pending' | 'success' | 'failed';
  dataSnapshot?: any;
}

export interface NOVARequest {
  query: string;
  userId?: string;
  module?: 'learn_easy' | 'concept_coach' | 'rag_query' | 'adaptive_quiz';
  learnerProfile?: Partial<LearnerProfile>;
  customOptions?: {
    forceReadingLevel?: string;
    includeQuiz?: boolean;
    simplifyLanguage?: boolean;
    dyslexiaFriendly?: boolean;
  };
}

export class NOVAContext {
  public request: NOVARequest;
  public userId: string;
  private data: Map<string, any> = new Map();
  public traceLogs: NOVAStageTrace[] = [];

  constructor(request: NOVARequest) {
    this.request = request;
    this.userId = request.userId || "default_student";
  }

  set(key: string, value: any): void {
    this.data.set(key, value);
  }

  get<T = any>(key: string): T {
    return this.data.get(key) as T;
  }

  has(key: string): boolean {
    return this.data.has(key);
  }

  logStage(stageName: string, startTime: number, status: 'success' | 'failed', snapshot?: any) {
    const endTime = Date.now();
    this.traceLogs.push({
      stageName,
      startTime,
      endTime,
      durationMs: endTime - startTime,
      status,
      dataSnapshot: snapshot,
    });
  }
}
