import gemmaService from "../../ai/GemmaService.js";
import { NOVAContext } from "../NOVAContext.js";

export default class GemmaStage {
  get name() {
    return "GEMMA";
  }

  async execute(context: NOVAContext): Promise<void> {
    const prompt = context.get<string>("prompt");
    const systemInstruction = context.get<string>("systemInstruction");

    const response = await gemmaService.generate(prompt, systemInstruction);
    context.set("gemmaResponse", response);
  }
}
