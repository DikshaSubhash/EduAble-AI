import { composePrompt } from "../prompt/PromptComposer.js";
import { NOVAContext } from "../NOVAContext.js";

export default class PromptStage {
  get name() {
    return "PROMPT";
  }

  async execute(context: NOVAContext): Promise<void> {
    const request = context.request;

    const { prompt, systemInstruction } = composePrompt({
      query: request.query,
      module: request.module,
      retrievedContext: context.get("retrievedContext"),
      learnerProfile: request.learnerProfile,
      customOptions: request.customOptions,
    });

    context.set("prompt", prompt);
    context.set("systemInstruction", systemInstruction);
  }
}
