import ragEngine from "../../rag/RAGEngine.js";
import { NOVAContext } from "../NOVAContext.js";

export default class RAGStage {
  get name() {
    return "RAG";
  }

  async execute(context: NOVAContext): Promise<void> {
    const request = context.request;
    if (!request.query) {
      throw new Error("Query is required for RAGStage.");
    }

    const retrievedContext = await ragEngine.retrieve(request.query, 4);
    context.set("retrievedContext", retrievedContext);
  }
}
