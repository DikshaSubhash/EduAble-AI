import { evaluate } from "../evaluation/EvaluationEngine.js";
import { NOVAContext } from "../NOVAContext.js";

export default class EvaluationStage {
  get name() {
    return "EVALUATION";
  }

  async execute(context: NOVAContext): Promise<void> {
    const guardedResponse = context.get<any>("guardedResponse");
    const retrievedContext = context.get<any[]>("retrievedContext") || [];

    const report = evaluate(
      context.request,
      guardedResponse?.response?.text || "",
      retrievedContext
    );

    context.set("evaluation", report);
    context.set("response", {
      answer: guardedResponse?.response?.text || "",
      evaluation: report,
      guardedResponse,
      retrievedContext,
    });
  }
}
