import { applyGuardrails } from "../guardrails/GuardrailEngine.js";
import { NOVAContext } from "../NOVAContext.js";

export default class GuardrailStage {
  get name() {
    return "GUARDRAILS";
  }

  async execute(context: NOVAContext): Promise<void> {
    const rawGemmaResponse = context.get<string>("gemmaResponse");

    const result = applyGuardrails(context.request, rawGemmaResponse);
    context.set("guardedResponse", result);
  }
}
