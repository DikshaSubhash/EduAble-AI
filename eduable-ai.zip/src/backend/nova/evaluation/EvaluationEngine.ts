export interface EvaluationReport {
  overallScore: number;
  readabilityGrade: string;
  readabilityScore: number;
  factualityConfidence: number;
  toneAppropriateness: number;
  accessibilityCompliance: number;
  feedback: string[];
}

export function evaluate(request: any, responseText: string, retrievedContext: any[] = []): EvaluationReport {
  const feedback: string[] = [];
  const text = responseText || "";

  // 1. Calculate Readability Score
  const words = text.split(/\s+/).filter(Boolean);
  const sentences = text.split(/[.!?]+/).filter(Boolean);
  const wordCount = words.length || 1;
  const sentenceCount = sentences.length || 1;

  const avgWordsPerSentence = wordCount / sentenceCount;
  
  let readabilityGrade = "High School (Grade 10)";
  let readabilityScore = 75;

  if (avgWordsPerSentence < 10) {
    readabilityGrade = "Elementary (Grade 5)";
    readabilityScore = 90;
    feedback.push("Excellent short sentence structure for elementary/ADHD readers.");
  } else if (avgWordsPerSentence < 16) {
    readabilityGrade = "Middle School (Grade 8)";
    readabilityScore = 85;
    feedback.push("Good balanced sentence length for middle school readability.");
  } else if (avgWordsPerSentence < 22) {
    readabilityGrade = "High School (Grade 11)";
    readabilityScore = 75;
  } else {
    readabilityGrade = "College / Professional";
    readabilityScore = 65;
    feedback.push("Long sentences detected; consider chunking into smaller paragraphs.");
  }

  // 2. Factuality & Grounding Alignment
  let factualityConfidence = 0.88;
  if (retrievedContext && retrievedContext.length > 0) {
    // Check keyword overlap between response and retrieved context
    const contextText = retrievedContext.map((c) => c.text).join(" ").toLowerCase();
    const topWords = words.filter((w) => w.length > 4).slice(0, 20);
    let matches = 0;
    for (const word of topWords) {
      if (contextText.includes(word.toLowerCase())) matches++;
    }
    const overlapRatio = topWords.length > 0 ? matches / topWords.length : 0.5;
    factualityConfidence = Math.min(0.99, Math.max(0.75, 0.70 + overlapRatio * 0.3));
    feedback.push(`Grounding factual overlap confidence: ${Math.round(factualityConfidence * 100)}%`);
  } else {
    feedback.push("Direct model reasoning without document context grounding.");
  }

  // 3. Tone Appropriateness (Encouraging, Supportive)
  let toneAppropriateness = 92;
  if (/great question|excellent|let's break this down|imagine|step-by-step|key takeaway/i.test(text)) {
    toneAppropriateness = 98;
    feedback.push("Supportive pedagogical tone verified.");
  }

  // 4. Accessibility Compliance
  let accessibilityCompliance = 90;
  if (text.includes("•") || text.includes("- ") || text.includes("1.")) {
    accessibilityCompliance += 5;
    feedback.push("Scannable bullet points present.");
  }

  const overallScore = Math.round(
    readabilityScore * 0.3 +
    factualityConfidence * 100 * 0.3 +
    toneAppropriateness * 0.2 +
    accessibilityCompliance * 0.2
  );

  return {
    overallScore,
    readabilityGrade,
    readabilityScore,
    factualityConfidence: Math.round(factualityConfidence * 100) / 100,
    toneAppropriateness,
    accessibilityCompliance: Math.min(100, accessibilityCompliance),
    feedback,
  };
}
