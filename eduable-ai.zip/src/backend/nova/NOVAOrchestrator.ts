import { NOVAContext, NOVARequest } from "./NOVAContext.js";
import RAGStage from "./stages/RAGStage.js";
import PromptStage from "./stages/PromptStage.js";
import GemmaStage from "./stages/GemmaStage.js";
import GuardrailStage from "./stages/GuardrailStage.js";
import EvaluationStage from "./stages/EvaluationStage.js";
import learnerRepository from "../database/repositories/LearnerRepository.js";
import sessionRepository from "../database/repositories/SessionRepository.js";

export interface NOVAStage {
  name: string;
  execute(context: NOVAContext): Promise<void>;
}

export class NOVAOrchestrator {
  private stages: NOVAStage[];

  constructor(stages?: NOVAStage[]) {
    this.stages = stages || [
      new RAGStage(),
      new PromptStage(),
      new GemmaStage(),
      new GuardrailStage(),
      new EvaluationStage(),
    ];
  }

  async run(request: NOVARequest): Promise<{
    answer: string;
    evaluation: any;
    traceLogs: any[];
    retrievedContext: any[];
    guardedResponse: any;
    sessionId?: string;
  }> {
    // Populate learner profile if not provided
    const userId = request.userId || "default_student";
    if (!request.learnerProfile) {
      request.learnerProfile = await learnerRepository.findByUserId(userId);
    }

    const context = new NOVAContext(request);

    for (const stage of this.stages) {
      const start = Date.now();
      try {
        await stage.execute(context);
        let snapshot = null;
        if (stage.name === "RAG") snapshot = { chunks: (context.get("retrievedContext") || []).length };
        if (stage.name === "EVALUATION") snapshot = { score: context.get("evaluation")?.overallScore };

        context.logStage(stage.name, start, "success", snapshot);
      } catch (err: any) {
        console.error(`NOVA Stage ${stage.name} error:`, err);
        context.logStage(stage.name, start, "failed", { error: err.message });
        throw err;
      }
    }

    const finalResponse = context.get<any>("response") || {};
    const evaluation = context.get<any>("evaluation");

    // Save session to repository
    const session = await sessionRepository.save({
      userId,
      module: request.module || "learn_easy",
      query: request.query,
      response: finalResponse.answer || "",
      retrievedContext: context.get("retrievedContext"),
      promptUsed: context.get("prompt"),
      evaluation,
      guardedResponse: context.get("guardedResponse"),
    });

    return {
      answer: finalResponse.answer || "",
      evaluation,
      traceLogs: context.traceLogs,
      retrievedContext: context.get("retrievedContext") || [],
      guardedResponse: context.get("guardedResponse"),
      sessionId: session.id,
    };
  }
}

export default new NOVAOrchestrator();
