import { LearnerProfile } from "../../database/models/Learner.js";

export interface ComposePromptInput {
  query: string;
  retrievedContext?: any[];
  learnerProfile?: Partial<LearnerProfile>;
  module?: string;
  customOptions?: any;
}

export function composePrompt(input: ComposePromptInput): { prompt: string; systemInstruction: string } {
  const query = input.query;
  const context = input.retrievedContext || [];
  const profile = input.learnerProfile || {};
  const moduleType = input.module || "learn_easy";

  const readingLevel = input.customOptions?.forceReadingLevel || profile.readingLevel || "high_school";
  const learningStyle = profile.learningStyle || "adhd_chunked";
  const accessibility = profile.accessibility || [];

  let contextFormatted = "None.";
  if (context && context.length > 0) {
    contextFormatted = context
      .map((c: any, i: number) => `[Reference ${i + 1} - Score ${(c.score * 100).toFixed(0)}%]:\n${c.text}`)
      .join("\n\n");
  }

  // Reading level guide
  const readingLevelGuides: Record<string, string> = {
    elementary: "Use simple words, short sentences, fun analogies, and clear 5th-grade vocabulary.",
    middle_school: "Use clear middle-school terms, straightforward explanations, and concrete examples.",
    high_school: "Provide high-school level depth, structured key terms, step-by-step logic, and application examples.",
    college: "Deliver comprehensive undergraduate-level academic explanations, foundational theory, and analytical rigor.",
    expert: "Provide advanced technical detail, research context, and domain-specific terminology.",
  };

  // Accessibility formatting instructions
  let formatRules: string[] = [];
  if (learningStyle === "adhd_chunked" || accessibility.includes("short_paragraphs")) {
    formatRules.push("• Break concepts into short, digestible bullet points (max 2-3 sentences per paragraph).");
    formatRules.push("• Use bold key concepts for rapid visual scanability.");
  }
  if (accessibility.includes("dyslexia_font") || input.customOptions?.dyslexiaFriendly) {
    formatRules.push("• Use clear, simple sentence structures with high semantic clarity.");
    formatRules.push("• Avoid complex multi-clause sentences or ambiguous jargon.");
  }
  if (learningStyle === "visual" || accessibility.includes("visual_cues")) {
    formatRules.push("• Include ASCII visual diagrams, emoji section indicators, or step-by-step flowcharts where helpful.");
  }

  const systemInstruction = `You are EduAble AI, an adaptive AI tutor and accessibility-first educator built on Gemma & Google AI.
Your goal is to explain complex topics clearly, adapt strictly to the student's reading level and accessibility needs, and ground answers in provided reference context.

Target Reading Level: ${readingLevel.toUpperCase()}
(${readingLevelGuides[readingLevel] || readingLevelGuides.high_school})

Formatting Guidelines:
${formatRules.length > 0 ? formatRules.join("\n") : "• Format cleanly with markdown, bullet points, and bold headers."}

Special Instructions:
- Ground your explanation in the provided RAG Reference Context if available.
- Always include a "Key Takeaway" box at the end.
- Include a "Quick Self-Check Question" to test understanding.`;

  const prompt = `Student Question / Topic:
${query}

Grounding Reference Context (RAG):
${contextFormatted}

Please provide an engaging, highly accessible, and tailored explanation for the student now.`;

  return { prompt, systemInstruction };
}
