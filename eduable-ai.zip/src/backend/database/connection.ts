import dotenv from "dotenv";

dotenv.config();

export async function connectDatabase() {
  const uri = process.env.MONGODB_URI;
  if (!uri) {
    console.log("MongoDB URI not provided. Using EduAble high-speed in-memory repository store.");
    return false;
  }

  try {
    // Dynamic import for optional Mongoose dependency
    const mongooseModule: any = await import("mongoose" as any);
    const mongoose = mongooseModule.default || mongooseModule;
    await mongoose.connect(uri, {
      dbName: "eduable_ai",
    });
    console.log("MongoDB Connected Successfully to eduable_ai");
    return true;
  } catch (error) {
    console.warn("MongoDB connection warning. Falling back to in-memory store:", error);
    return false;
  }
}
