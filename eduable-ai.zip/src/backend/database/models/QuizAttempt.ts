export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  explanation: string;
  topicTag: string;
}

export interface QuizAttempt {
  id: string;
  userId: string;
  topic: string;
  score: number;
  totalQuestions: number;
  userAnswers: number[];
  questions: QuizQuestion[];
  evaluationFeedback: string;
  completedAt: Date;
}
