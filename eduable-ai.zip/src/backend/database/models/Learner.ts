export interface LearnerProfile {
  userId: string;
  name?: string;
  email?: string;
  learningStyle: 'visual' | 'auditory' | 'kinesthetic' | 'reading_writing' | 'adhd_chunked' | 'dyslexia_friendly';
  readingLevel: 'elementary' | 'middle_school' | 'high_school' | 'college' | 'expert';
  accessibility: string[]; // e.g. ["high_contrast", "dyslexia_font", "audio_tts", "short_paragraphs"]
  language: string;
  interests: string[];
  weakTopics: string[];
  completedTopics: string[];
  careerGoal?: string;
  createdAt: Date;
  updatedAt: Date;
}
