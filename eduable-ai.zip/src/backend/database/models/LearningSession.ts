export interface LearningSession {
  id?: string;
  userId: string;
  module: 'learn_easy' | 'concept_coach' | 'rag_query' | 'adaptive_quiz';
  query: string;
  response: string;
  retrievedContext?: any[];
  promptUsed?: string;
  evaluation?: {
    overallScore: number;
    readabilityGrade: string;
    factualityConfidence: number;
    toneAppropriateness: number;
    accessibilityCompliance: number;
    feedback: string[];
  };
  guardedResponse?: any;
  createdAt: Date;
}
