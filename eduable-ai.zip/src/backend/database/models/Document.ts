export interface IndexedDocumentRecord {
  id: string;
  userId: string;
  title: string;
  fileType: string;
  chunkCount: number;
  pages?: number;
  uploadedAt: Date;
  summary?: string;
}
