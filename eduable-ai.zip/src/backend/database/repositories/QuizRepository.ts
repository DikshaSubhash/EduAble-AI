import { QuizAttempt } from "../models/QuizAttempt.js";

class QuizRepository {
  private attempts: QuizAttempt[] = [];

  async saveAttempt(attempt: QuizAttempt): Promise<QuizAttempt> {
    this.attempts.unshift(attempt);
    return attempt;
  }

  async getAttemptsByUser(userId: string): Promise<QuizAttempt[]> {
    return this.attempts.filter((a) => a.userId === userId || userId === "all");
  }
}

export default new QuizRepository();
