import { LearningSession } from "../models/LearningSession.js";

class SessionRepository {
  private sessions: LearningSession[] = [];

  async save(session: Omit<LearningSession, "id" | "createdAt"> & { id?: string; createdAt?: Date }): Promise<LearningSession> {
    const newSession: LearningSession = {
      ...session,
      id: session.id || `session_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdAt: session.createdAt || new Date(),
    };

    this.sessions.unshift(newSession); // Newest first
    return newSession;
  }

  async history(userId: string, limit = 20): Promise<LearningSession[]> {
    return this.sessions
      .filter((s) => s.userId === userId || userId === "all")
      .slice(0, limit);
  }

  async findById(sessionId: string): Promise<LearningSession | undefined> {
    return this.sessions.find((s) => s.id === sessionId);
  }

  async getMetrics(userId: string) {
    const userSessions = this.sessions.filter((s) => s.userId === userId);
    if (userSessions.length === 0) {
      return {
        totalSessions: 0,
        averageEvaluationScore: 0,
        avgFactuality: 0,
        avgAccessibilityCompliance: 0,
      };
    }

    const total = userSessions.length;
    const avgScore = userSessions.reduce((acc, s) => acc + (s.evaluation?.overallScore || 85), 0) / total;
    const avgFact = userSessions.reduce((acc, s) => acc + (s.evaluation?.factualityConfidence || 0.9), 0) / total;
    const avgAccess = userSessions.reduce((acc, s) => acc + (s.evaluation?.accessibilityCompliance || 90), 0) / total;

    return {
      totalSessions: total,
      averageEvaluationScore: Math.round(avgScore),
      avgFactuality: Math.round(avgFact * 100),
      avgAccessibilityCompliance: Math.round(avgAccess),
    };
  }
}

export default new SessionRepository();
