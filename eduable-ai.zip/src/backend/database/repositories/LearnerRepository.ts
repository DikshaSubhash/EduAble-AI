import { LearnerProfile } from "../models/Learner.js";

class LearnerRepository {
  private learners: Map<string, LearnerProfile> = new Map();

  constructor() {
    // Seed default demo profile
    this.learners.set("default_student", {
      userId: "default_student",
      name: "Alex Johnson",
      email: "alex.johnson@eduable.ai",
      learningStyle: "adhd_chunked",
      readingLevel: "high_school",
      accessibility: ["dyslexia_font", "short_paragraphs", "visual_cues"],
      language: "English",
      interests: ["Artificial Intelligence", "Space Exploration", "Biology"],
      weakTopics: ["Vector Space Models", "Linear Algebra Math"],
      completedTopics: ["Intro to Machine Learning", "Cellular Respiration"],
      careerGoal: "AI Software Engineer & Accessibility Advocate",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  }

  async findByUserId(userId: string): Promise<LearnerProfile> {
    const existing = this.learners.get(userId);
    if (existing) return existing;

    // Return a default profile template if not found
    const newProfile: LearnerProfile = {
      userId,
      name: "Learner",
      learningStyle: "adhd_chunked",
      readingLevel: "high_school",
      accessibility: ["short_paragraphs"],
      language: "English",
      interests: [],
      weakTopics: [],
      completedTopics: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.learners.set(userId, newProfile);
    return newProfile;
  }

  async create(profile: Partial<LearnerProfile> & { userId: string }): Promise<LearnerProfile> {
    const fullProfile: LearnerProfile = {
      userId: profile.userId,
      name: profile.name || "Learner",
      email: profile.email || "",
      learningStyle: profile.learningStyle || "adhd_chunked",
      readingLevel: profile.readingLevel || "high_school",
      accessibility: profile.accessibility || [],
      language: profile.language || "English",
      interests: profile.interests || [],
      weakTopics: profile.weakTopics || [],
      completedTopics: profile.completedTopics || [],
      careerGoal: profile.careerGoal || "",
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.learners.set(profile.userId, fullProfile);
    return fullProfile;
  }

  async update(userId: string, data: Partial<LearnerProfile>): Promise<LearnerProfile> {
    const current = await this.findByUserId(userId);
    const updated: LearnerProfile = {
      ...current,
      ...data,
      userId,
      updatedAt: new Date(),
    };
    this.learners.set(userId, updated);
    return updated;
  }
}

export default new LearnerRepository();
