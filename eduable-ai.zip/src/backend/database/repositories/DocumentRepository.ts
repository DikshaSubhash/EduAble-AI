import { IndexedDocumentRecord } from "../models/Document.js";

class DocumentRepository {
  private documents: Map<string, IndexedDocumentRecord> = new Map();

  async save(doc: IndexedDocumentRecord): Promise<IndexedDocumentRecord> {
    this.documents.set(doc.id, doc);
    return doc;
  }

  async listByUser(userId: string): Promise<IndexedDocumentRecord[]> {
    return Array.from(this.documents.values()).filter(
      (d) => d.userId === userId || d.userId === "default_student"
    );
  }

  async delete(id: string): Promise<boolean> {
    return this.documents.delete(id);
  }
}

export default new DocumentRepository();
