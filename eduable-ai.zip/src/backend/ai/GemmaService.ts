import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const apiKey = process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || "";

const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

const DEFAULT_MODEL = "gemini-3.6-flash";

export class GemmaService {
  /**
   * Generates text content given a prompt and optional system instruction.
   */
  async generate(prompt: string, systemInstruction?: string): Promise<string> {
    if (!prompt || !prompt.trim()) {
      throw new Error("Prompt cannot be empty for Gemma generation.");
    }

    try {
      const response = await ai.models.generateContent({
        model: DEFAULT_MODEL,
        contents: prompt,
        config: systemInstruction ? { systemInstruction } : undefined,
      });

      return response.text || "No response text generated.";
    } catch (error: any) {
      console.error("GemmaService generation error:", error);
      throw new Error(`Gemma AI Generation Failed: ${error.message || error}`);
    }
  }

  /**
   * Generates structured JSON output based on a prompt and optional schema description.
   */
  async generateJSON<T = any>(prompt: string, systemInstruction?: string): Promise<T> {
    try {
      const response = await ai.models.generateContent({
        model: DEFAULT_MODEL,
        contents: prompt,
        config: {
          systemInstruction: (systemInstruction ? systemInstruction + "\n" : "") + "Return valid JSON format strictly.",
          responseMimeType: "application/json",
        },
      });

      const text = response.text?.trim() || "{}";
      return JSON.parse(text) as T;
    } catch (error: any) {
      console.error("GemmaService JSON generation error:", error);
      // Fallback clean extraction
      try {
        const text = await this.generate(prompt, systemInstruction);
        const match = text.match(/\{[\s\S]*\}|\[[\s\S]*\]/);
        if (match) {
          return JSON.parse(match[0]);
        }
      } catch (innerError) {
        console.error("Fallback JSON parsing failed:", innerError);
      }
      throw error;
    }
  }
}

export default new GemmaService();
