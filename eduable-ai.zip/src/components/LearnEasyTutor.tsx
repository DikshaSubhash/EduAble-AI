import React, { useState } from 'react';
import { Sparkles, Send, BookOpen, CheckCircle, ShieldCheck, Cpu, Lightbulb, FileText, RefreshCw } from 'lucide-react';
import { LearnerProfile, NOVAResponse } from '../types';

interface LearnEasyTutorProps {
  learnerProfile: LearnerProfile;
  onUpdateProfile: (data: Partial<LearnerProfile>) => void;
  onViewPipeline: (response: NOVAResponse) => void;
}

export const LearnEasyTutor: React.FC<LearnEasyTutorProps> = ({
  learnerProfile,
  onUpdateProfile,
  onViewPipeline,
}) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [novaResponse, setNovaResponse] = useState<NOVAResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedReadingLevel, setSelectedReadingLevel] = useState<string>(
    learnerProfile.readingLevel || 'high_school'
  );

  const samplePrompts = [
    'Explain how Vector Embeddings & RAG work',
    'What is Neural Network Overfitting?',
    'How does Photosynthesis work?',
    'Explain Quantum Superposition',
  ];

  const handleQuery = async (e?: React.FormEvent, customText?: string) => {
    if (e) e.preventDefault();
    const textToSubmit = customText || query;
    if (!textToSubmit.trim() || loading) return;

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/nova/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: textToSubmit,
          userId: learnerProfile.userId || 'default_student',
          module: 'learn_easy',
          customOptions: {
            forceReadingLevel: selectedReadingLevel,
          },
          learnerProfile: {
            ...learnerProfile,
            readingLevel: selectedReadingLevel as any,
          },
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const data: NOVAResponse = await res.json();
      setNovaResponse(data);
      if (customText) setQuery(customText);
    } catch (err: any) {
      console.error('Query execution error:', err);
      setError(err.message || 'Failed to generate response. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 rounded-2xl border border-indigo-500/20 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 text-indigo-400 font-semibold text-sm mb-1">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>LearnEasy Adaptive AI Tutor</span>
            </div>
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Personalized Conceptual Learning
            </h1>
            <p className="text-slate-300 text-sm mt-1 max-w-2xl">
              Powered by NOVA Orchestrator pipeline (RAG ➔ Prompt ➔ Gemma ➔ Guardrails ➔ Evaluation) tailored to your accessibility needs and reading level.
            </p>
          </div>

          {/* Reading Level Selector */}
          <div className="bg-slate-800/80 p-3 rounded-xl border border-slate-700/80 flex flex-col space-y-1.5">
            <label className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
              Target Reading Level
            </label>
            <select
              value={selectedReadingLevel}
              onChange={(e) => {
                setSelectedReadingLevel(e.target.value);
                onUpdateProfile({ readingLevel: e.target.value as any });
              }}
              className="bg-slate-900 text-slate-200 text-xs font-semibold px-3 py-1.5 rounded-lg border border-indigo-500/30 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="elementary">Grade 5 (Elementary)</option>
              <option value="middle_school">Grade 8 (Middle School)</option>
              <option value="high_school">Grade 11 (High School)</option>
              <option value="college">College / Undergraduate</option>
              <option value="expert">Expert / Technical</option>
            </select>
          </div>
        </div>
      </div>

      {/* Query Form & Prompt Starters */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg space-y-4">
        <form onSubmit={(e) => handleQuery(e)} className="space-y-3">
          <div className="relative">
            <textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ask anything or request a concept breakdown (e.g. 'Explain how neural networks learn with backpropagation')..."
              rows={3}
              className="w-full bg-slate-950 text-slate-100 placeholder-slate-500 text-sm p-4 rounded-xl border border-slate-700/80 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 focus:outline-none transition-all resize-none"
            />
            <button
              type="submit"
              disabled={loading || !query.trim()}
              className="absolute right-3 bottom-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium text-xs px-4 py-2 rounded-lg flex items-center space-x-2 transition-all shadow-md shadow-indigo-600/30"
            >
              {loading ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Processing NOVA...</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Ask Tutor</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Quick Sample Prompts */}
        <div className="flex flex-wrap items-center gap-2 pt-2">
          <span className="text-xs font-medium text-slate-400 flex items-center space-x-1">
            <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
            <span>Try asking:</span>
          </span>
          {samplePrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleQuery(undefined, p)}
              disabled={loading}
              className="text-xs bg-slate-800 hover:bg-indigo-900/40 text-slate-300 hover:text-indigo-200 border border-slate-700/80 hover:border-indigo-500/40 px-3 py-1 rounded-full transition-all"
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      {/* Error Alert */}
      {error && (
        <div className="bg-red-950/60 border border-red-500/40 text-red-200 p-4 rounded-xl text-xs flex items-center justify-between">
          <span>{error}</span>
          <button onClick={() => setError(null)} className="text-red-400 font-bold hover:text-red-100">
            Dismiss
          </button>
        </div>
      )}

      {/* Response Card */}
      {novaResponse && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-xl overflow-hidden space-y-0">
          {/* Response Header & Pipeline Summary */}
          <div className="bg-slate-800/80 px-6 py-4 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-indigo-300">
                <BookOpen className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs text-slate-400">EduAble Adaptive Answer</span>
                <div className="flex items-center space-x-2 text-xs font-medium text-slate-200">
                  <span>Grade: {novaResponse.evaluation?.readabilityGrade}</span>
                  <span className="text-slate-600">•</span>
                  <span className="text-emerald-400 flex items-center space-x-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Safety Score {(novaResponse.guardedResponse?.safetyScore * 100).toFixed(0)}%</span>
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => onViewPipeline(novaResponse)}
              className="text-xs bg-indigo-900/60 hover:bg-indigo-800/80 text-indigo-200 border border-indigo-500/40 px-3.5 py-1.5 rounded-lg flex items-center space-x-1.5 transition-colors"
            >
              <Cpu className="w-3.5 h-3.5 text-indigo-400" />
              <span>Inspect NOVA Stage Execution</span>
            </button>
          </div>

          {/* RAG Context Banner if Grounded */}
          {novaResponse.retrievedContext && novaResponse.retrievedContext.length > 0 && (
            <div className="bg-indigo-950/40 border-b border-indigo-800/30 px-6 py-2.5 flex items-center space-x-2 text-xs text-indigo-300">
              <FileText className="w-3.5 h-3.5 text-indigo-400" />
              <span>
                Grounded in <strong>{novaResponse.retrievedContext.length} document chunk(s)</strong> from RAG Knowledge Store.
              </span>
            </div>
          )}

          {/* Main Answer Content */}
          <div className="p-6 text-slate-200 text-sm leading-relaxed space-y-4 whitespace-pre-line">
            {novaResponse.answer}
          </div>

          {/* Evaluation Footer */}
          {novaResponse.evaluation && (
            <div className="bg-slate-950 px-6 py-4 border-t border-slate-800 flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
              <div className="flex items-center space-x-4">
                <span>
                  Factuality Confidence: <strong className="text-slate-200">{(novaResponse.evaluation.factualityConfidence * 100).toFixed(0)}%</strong>
                </span>
                <span>
                  Accessibility Compliance: <strong className="text-slate-200">{novaResponse.evaluation.accessibilityCompliance}%</strong>
                </span>
              </div>

              <div className="flex items-center space-x-1 text-emerald-400">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>Overall Quality Score: {novaResponse.evaluation.overallScore}/100</span>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
