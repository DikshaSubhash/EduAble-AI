import React, { useState, useEffect } from 'react';
import { FileText, Upload, Search, CheckCircle2, Layers, Trash2, ArrowRight, FileCheck, Sparkles } from 'lucide-react';
import { IndexedDocumentRecord } from '../types';

interface RAGKnowledgeHubProps {
  userId: string;
  onSelectTopicForTutor: (topic: string) => void;
}

export const RAGKnowledgeHub: React.FC<RAGKnowledgeHubProps> = ({
  userId,
  onSelectTopicForTutor,
}) => {
  const [documents, setDocuments] = useState<IndexedDocumentRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [docTitle, setDocTitle] = useState('');
  const [rawText, setRawText] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searching, setSearching] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  useEffect(() => {
    fetchDocuments();
  }, [userId]);

  const fetchDocuments = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/rag/documents?userId=${userId}`);
      if (res.ok) {
        const data = await res.json();
        setDocuments(data.documents || []);
      }
    } catch (err) {
      console.error('Failed to fetch documents:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docTitle.trim() || (!rawText.trim() && !file) || uploading) return;

    setUploading(true);
    setStatusMsg(null);

    try {
      let base64Content: string | undefined;
      let mimeType = 'text/plain';

      if (file) {
        mimeType = file.type || 'application/pdf';
        const reader = new FileReader();
        base64Content = await new Promise((resolve) => {
          reader.onload = (event) => resolve(event.target?.result as string);
          reader.readAsDataURL(file);
        });
      }

      const res = await fetch('/api/rag/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: docTitle,
          content: rawText,
          base64Content,
          mimeType,
          userId,
        }),
      });

      if (!res.ok) throw new Error('Upload failed');

      const data = await res.json();
      setStatusMsg(`Successfully indexed "${data.document.title}" into ${data.indexResult.indexedChunks} chunks!`);
      setDocTitle('');
      setRawText('');
      setFile(null);
      fetchDocuments();
    } catch (err: any) {
      console.error('Upload error:', err);
      setStatusMsg('Failed to index document: ' + err.message);
    } finally {
      setUploading(false);
    }
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim() || searching) return;

    setSearching(true);
    try {
      const res = await fetch('/api/rag/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery, limit: 5 }),
      });
      if (res.ok) {
        const data = await res.json();
        setSearchResults(data.results || []);
      }
    } catch (err) {
      console.error('Search error:', err);
    } finally {
      setSearching(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 text-indigo-400 font-semibold text-sm mb-1">
            <Layers className="w-4 h-4 text-indigo-400" />
            <span>RAG Document Store & Vector Retrieval</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Grounding Knowledge Hub
          </h1>
          <p className="text-slate-300 text-sm mt-1">
            Index textbooks, research papers, or study notes. All queries in EduAble AI automatically retrieve grounding context from these documents.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Document Indexing Form */}
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg space-y-4">
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <Upload className="w-4 h-4 text-indigo-400" />
            <span>Index New Document</span>
          </h2>

          <form onSubmit={handleFileUpload} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Document Title</label>
              <input
                type="text"
                placeholder="e.g., Biology Chapter 4 - Cellular Respiration"
                value={docTitle}
                onChange={(e) => setDocTitle(e.target.value)}
                className="w-full bg-slate-950 text-slate-100 text-xs p-3 rounded-xl border border-slate-700/80 focus:border-indigo-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Upload PDF / File OR Paste Plain Text</label>
              <input
                type="file"
                accept=".pdf,.txt,.md,.json"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
                className="w-full text-xs text-slate-300 file:mr-3 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-500 cursor-pointer bg-slate-950 p-2 rounded-xl border border-slate-800"
              />
            </div>

            <div className="text-center text-xs text-slate-500 font-medium">- OR -</div>

            <div>
              <textarea
                placeholder="Paste course notes, lesson summaries, or study guide text here..."
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                rows={4}
                className="w-full bg-slate-950 text-slate-100 text-xs p-3 rounded-xl border border-slate-700/80 focus:border-indigo-500 focus:outline-none resize-none"
              />
            </div>

            <button
              type="submit"
              disabled={uploading || !docTitle.trim() || (!rawText.trim() && !file)}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium text-xs py-2.5 rounded-xl flex items-center justify-center space-x-2 transition-all shadow-md shadow-indigo-600/30"
            >
              {uploading ? (
                <span>Chunking & Embedding Vectors...</span>
              ) : (
                <>
                  <FileCheck className="w-4 h-4" />
                  <span>Index Document into Vector Store</span>
                </>
              )}
            </button>
          </form>

          {statusMsg && (
            <div className="bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 p-3 rounded-xl text-xs flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{statusMsg}</span>
            </div>
          )}
        </div>

        {/* Semantic Vector Search Test */}
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg space-y-4">
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <Search className="w-4 h-4 text-sky-400" />
            <span>Test Vector Retrieval & Grounding</span>
          </h2>

          <form onSubmit={handleSearch} className="flex space-x-2">
            <input
              type="text"
              placeholder="Search query to test embedding similarity..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-slate-950 text-slate-100 text-xs p-3 rounded-xl border border-slate-700/80 focus:border-indigo-500 focus:outline-none"
            />
            <button
              type="submit"
              disabled={searching || !searchQuery.trim()}
              className="bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-xs px-4 py-2 rounded-xl font-medium"
            >
              Search
            </button>
          </form>

          {/* Search Results */}
          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {searchResults.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">
                Enter a query to test semantic vector match against indexed documents.
              </p>
            ) : (
              searchResults.map((res, idx) => (
                <div key={idx} className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1 text-xs">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="font-semibold text-indigo-300">
                      {res.metadata?.docTitle || 'Indexed Chunk'}
                    </span>
                    <span className="bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded-md font-mono">
                      Match: {(res.score * 100).toFixed(1)}%
                    </span>
                  </div>
                  <p className="text-slate-300 line-clamp-3 leading-relaxed">{res.text}</p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Indexed Documents Table */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <FileText className="w-4 h-4 text-indigo-400" />
            <span>Indexed Documents Collection ({documents.length})</span>
          </h2>
        </div>

        {documents.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-xs">
            No documents indexed yet. Upload course materials above to ground AI answers.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {documents.map((doc) => (
              <div key={doc.id} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-semibold text-slate-200 text-sm line-clamp-1">{doc.title}</h3>
                    <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-full uppercase">
                      {doc.fileType.split('/')[1] || 'doc'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-2">{doc.summary}</p>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <span className="text-indigo-400 font-mono text-[11px]">
                    {doc.chunkCount} vector chunks
                  </span>
                  <button
                    onClick={() => onSelectTopicForTutor(`Based on document "${doc.title}": explain key concepts`)}
                    className="text-xs text-indigo-300 hover:text-white flex items-center space-x-1 font-medium"
                  >
                    <span>Ask Tutor</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
