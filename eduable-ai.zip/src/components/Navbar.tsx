import React from 'react';
import { Sparkles, BookOpen, Cpu, FileText, Settings, Activity, Brain } from 'lucide-react';
import { LearnerProfile } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  learnerProfile: LearnerProfile | null;
  dyslexiaFontEnabled: boolean;
  setDyslexiaFontEnabled: (val: boolean) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  learnerProfile,
  dyslexiaFontEnabled,
  setDyslexiaFontEnabled,
}) => {
  const tabs = [
    { id: 'learn', label: 'LearnEasy Tutor', icon: Sparkles },
    { id: 'rag', label: 'RAG Knowledge Hub', icon: FileText },
    { id: 'nova', label: 'NOVA Visualizer', icon: Cpu },
    { id: 'quiz', label: 'Adaptive Quiz', icon: Brain },
    { id: 'analytics', label: 'Session History', icon: Activity },
    { id: 'profile', label: 'Learner Profile', icon: Settings },
  ];

  return (
    <header className="sticky top-0 z-50 bg-slate-900/95 backdrop-blur border-b border-slate-800 text-slate-100 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo & Badges */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('learn')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-sky-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-lg tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-slate-200 to-indigo-200">
                  EduAble AI
                </span>
                <span className="px-2 py-0.5 text-[10px] font-semibold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full">
                  Build with Gemma
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Adaptive Accessibility & RAG Learning System
              </p>
            </div>
          </div>

          {/* Learner Context Badges & Accessibility Toggles */}
          <div className="hidden md:flex items-center space-x-3">
            {learnerProfile && (
              <div className="flex items-center space-x-2 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/60 text-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="font-medium text-slate-200">{learnerProfile.name || 'Learner'}</span>
                <span className="text-slate-500">|</span>
                <span className="text-indigo-300 capitalize">{learnerProfile.readingLevel?.replace('_', ' ')}</span>
              </div>
            )}

            <button
              onClick={() => setDyslexiaFontEnabled(!dyslexiaFontEnabled)}
              title="Toggle Dyslexia-Friendly Readable Font"
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors border ${
                dyslexiaFontEnabled
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
              }`}
            >
              Aa Dyslexia Font
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex space-x-1 overflow-x-auto no-scrollbar py-2 border-t border-slate-800/80">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
