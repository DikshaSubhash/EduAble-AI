import React, { useState } from 'react';
import { Cpu, ShieldCheck, Activity, CheckCircle, Clock, FileText, ArrowRight, Sparkles, Layers } from 'lucide-react';
import { NOVAResponse } from '../types';

interface NOVAPipelineVisualizerProps {
  lastResponse: NOVAResponse | null;
}

export const NOVAPipelineVisualizer: React.FC<NOVAPipelineVisualizerProps> = ({ lastResponse }) => {
  const [selectedStage, setSelectedStage] = useState<string>('RAG');

  const stagesDef = [
    { name: 'RAG', desc: 'Vector Context Retrieval', icon: Layers },
    { name: 'PROMPT', desc: 'Adaptive Prompt Composer', icon: FileText },
    { name: 'GEMMA', desc: 'Google GenAI SDK Model', icon: Sparkles },
    { name: 'GUARDRAILS', desc: 'Safety & Structure Check', icon: ShieldCheck },
    { name: 'EVALUATION', desc: 'Readability & Quality Score', icon: Activity },
  ];

  if (!lastResponse) {
    return (
      <div className="max-w-5xl mx-auto bg-slate-900 p-8 rounded-2xl border border-slate-800 text-center space-y-4">
        <Cpu className="w-12 h-12 text-indigo-400 mx-auto animate-pulse" />
        <h2 className="text-xl font-bold text-white">NOVA Pipeline Visualizer</h2>
        <p className="text-slate-400 text-sm max-w-lg mx-auto">
          No pipeline execution trace recorded yet. Ask a question in the <strong>LearnEasy Tutor</strong> tab to trigger and inspect real-time stage logs here!
        </p>
      </div>
    );
  }

  const stageTraces = lastResponse.traceLogs || [];
  const currentStageTrace = stageTraces.find((t) => t.stageName === selectedStage);

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Banner */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2 text-indigo-400 font-semibold text-sm mb-1">
              <Cpu className="w-4 h-4 text-indigo-400" />
              <span>NOVA Orchestrator Pipeline Flow</span>
            </div>
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Real-Time Stage Execution Trace
            </h1>
            <p className="text-slate-300 text-sm mt-1">
              Click any pipeline stage below to inspect its timing, context snapshots, safety evaluation, and generated metrics.
            </p>
          </div>
          <div className="bg-slate-800 px-4 py-2 rounded-xl border border-slate-700 text-xs text-slate-300 font-mono">
            Session ID: {lastResponse.sessionId || 'active_session'}
          </div>
        </div>
      </div>

      {/* Stage Flow Chart */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 relative">
          {stagesDef.map((s, idx) => {
            const Icon = s.icon;
            const isSelected = selectedStage === s.name;
            const trace = stageTraces.find((t) => t.stageName === s.name);
            const durationMs = trace ? trace.durationMs : 0;

            return (
              <div
                key={s.name}
                onClick={() => setSelectedStage(s.name)}
                className={`p-4 rounded-xl border cursor-pointer transition-all flex flex-col justify-between space-y-3 ${
                  isSelected
                    ? 'bg-indigo-950/80 border-indigo-500 text-white shadow-lg shadow-indigo-500/20 ring-2 ring-indigo-500/30'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold tracking-wider uppercase text-indigo-400">
                    Step 0{idx + 1}
                  </span>
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                </div>

                <div>
                  <div className="flex items-center space-x-2">
                    <Icon className="w-4 h-4 text-indigo-300" />
                    <span className="font-bold text-sm text-slate-100">{s.name}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">{s.desc}</p>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500 flex items-center space-x-1">
                    <Clock className="w-3 h-3" />
                    <span>{durationMs}ms</span>
                  </span>
                  <span className="text-emerald-400 font-medium">PASS</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Selected Stage Detail Inspector */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-300">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-100 text-base">Stage Inspector: {selectedStage}</h3>
              <p className="text-xs text-slate-400">
                Execution Time: {currentStageTrace?.durationMs || 0} ms | Status: {currentStageTrace?.status || 'success'}
              </p>
            </div>
          </div>
        </div>

        {/* Stage Content Detail Switches */}
        {selectedStage === 'RAG' && (
          <div className="space-y-3 text-xs">
            <h4 className="font-semibold text-indigo-300">Retrieved Context Chunks ({lastResponse.retrievedContext.length})</h4>
            {lastResponse.retrievedContext.length === 0 ? (
              <p className="text-slate-500">No RAG documents retrieved for this query. Direct reasoning was used.</p>
            ) : (
              lastResponse.retrievedContext.map((c, i) => (
                <div key={i} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-1">
                  <div className="flex justify-between text-slate-400 font-mono text-[11px]">
                    <span>Chunk #{i + 1} ({c.metadata?.docTitle || 'Doc'})</span>
                    <span className="text-emerald-400">Similarity: {(c.score * 100).toFixed(1)}%</span>
                  </div>
                  <p className="text-slate-300 whitespace-pre-line">{c.text}</p>
                </div>
              ))
            )}
          </div>
        )}

        {selectedStage === 'GUARDRAILS' && (
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <span className="text-slate-400 block mb-1">Safety Rating</span>
                <span className="text-2xl font-bold text-emerald-400">
                  {(lastResponse.guardedResponse.safetyScore * 100).toFixed(0)}%
                </span>
              </div>
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800">
                <span className="text-slate-400 block mb-1">Violations / Triggers</span>
                <span className="text-2xl font-bold text-slate-200">
                  {lastResponse.guardedResponse.violations.length}
                </span>
              </div>
            </div>
          </div>
        )}

        {selectedStage === 'EVALUATION' && lastResponse.evaluation && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-400">Overall Quality</span>
              <div className="text-2xl font-bold text-emerald-400">{lastResponse.evaluation.overallScore}/100</div>
            </div>
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-400">Readability Grade</span>
              <div className="text-base font-bold text-indigo-300">{lastResponse.evaluation.readabilityGrade}</div>
            </div>
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-400">Factuality Confidence</span>
              <div className="text-2xl font-bold text-slate-200">
                {(lastResponse.evaluation.factualityConfidence * 100).toFixed(0)}%
              </div>
            </div>
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
              <span className="text-slate-400">Accessibility Compliance</span>
              <div className="text-2xl font-bold text-sky-400">{lastResponse.evaluation.accessibilityCompliance}%</div>
            </div>
          </div>
        )}

        {(selectedStage === 'PROMPT' || selectedStage === 'GEMMA') && (
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 text-xs text-slate-300 font-mono overflow-x-auto max-h-60">
            {selectedStage === 'PROMPT' ? 'Tailored system instructions & prompt assembled with user profile constraints.' : 'Gemma model generation executed via server-side @google/genai SDK.'}
          </div>
        )}
      </div>
    </div>
  );
};
