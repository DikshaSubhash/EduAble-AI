import React, { useState } from 'react';
import { Brain, CheckCircle, XCircle, RefreshCw, Award, ArrowRight, HelpCircle } from 'lucide-react';
import { QuizQuestion, QuizAttempt } from '../types';

interface AdaptiveQuizProps {
  userId: string;
}

export const AdaptiveQuiz: React.FC<AdaptiveQuizProps> = ({ userId }) => {
  const [topic, setTopic] = useState('Photosynthesis & Cellular Energy');
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);
  const [quizAttempt, setQuizAttempt] = useState<QuizAttempt | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleGenerateQuiz = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!topic.trim() || loading) return;

    setLoading(true);
    setQuizAttempt(null);
    setQuestions([]);
    setUserAnswers([]);

    try {
      const res = await fetch('/api/quiz/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, userId, questionCount: 3 }),
      });

      if (!res.ok) throw new Error('Failed to generate quiz');

      const data = await res.json();
      setQuestions(data.questions || []);
      setUserAnswers(new Array(data.questions.length).fill(-1));
    } catch (err: any) {
      console.error('Quiz error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectOption = (qIdx: number, oIdx: number) => {
    const updated = [...userAnswers];
    updated[qIdx] = oIdx;
    setUserAnswers(updated);
  };

  const handleSubmitQuiz = async () => {
    if (userAnswers.includes(-1) || submitting) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/quiz/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          topic,
          questions,
          userAnswers,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setQuizAttempt(data.attempt);
      }
    } catch (err) {
      console.error('Submit quiz error:', err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Quiz Top Form */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center space-x-2 text-indigo-400 font-semibold text-sm">
          <Brain className="w-4 h-4 text-purple-400" />
          <span>Gemma Adaptive Knowledge Assessment</span>
        </div>
        <h1 className="text-2xl font-bold text-white tracking-tight">
          Interactive Concept Check
        </h1>
        <p className="text-slate-300 text-sm">
          Generate an AI-crafted practice quiz grounded in your target topic or uploaded RAG documents.
        </p>

        <form onSubmit={handleGenerateQuiz} className="flex space-x-2 pt-2">
          <input
            type="text"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Enter topic or concept (e.g., Vector Space Models, Mitosis)..."
            className="flex-1 bg-slate-950 text-slate-100 text-xs p-3 rounded-xl border border-slate-700/80 focus:border-indigo-500 focus:outline-none"
          />
          <button
            type="submit"
            disabled={loading || !topic.trim()}
            className="bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-medium text-xs px-5 py-2.5 rounded-xl flex items-center space-x-2 transition-all shadow-md shadow-purple-600/30"
          >
            {loading ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Generating...</span>
              </>
            ) : (
              <>
                <Brain className="w-3.5 h-3.5" />
                <span>Generate Quiz</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* Questions Render */}
      {questions.length > 0 && !quizAttempt && (
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <h2 className="text-base font-bold text-slate-100">Topic: {topic}</h2>
            <span className="text-xs text-slate-400">{questions.length} Questions</span>
          </div>

          <div className="space-y-6">
            {questions.map((q, qIdx) => (
              <div key={q.id || qIdx} className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-start space-x-2">
                  <span className="font-bold text-indigo-400 text-sm">Q{qIdx + 1}.</span>
                  <p className="font-medium text-slate-200 text-sm">{q.question}</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  {q.options.map((opt, oIdx) => {
                    const isSelected = userAnswers[qIdx] === oIdx;
                    return (
                      <button
                        key={oIdx}
                        onClick={() => handleSelectOption(qIdx, oIdx)}
                        className={`text-left text-xs p-3 rounded-lg border transition-all ${
                          isSelected
                            ? 'bg-indigo-600 text-white border-indigo-500 font-semibold shadow-md shadow-indigo-600/30'
                            : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800 hover:border-slate-700'
                        }`}
                      >
                        {String.fromCharCode(65 + oIdx)}. {opt}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={handleSubmitQuiz}
            disabled={userAnswers.includes(-1) || submitting}
            className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-medium text-sm py-3 rounded-xl flex items-center justify-center space-x-2 transition-all shadow-lg shadow-emerald-600/30"
          >
            {submitting ? (
              <span>Evaluating Score...</span>
            ) : (
              <>
                <Award className="w-4 h-4" />
                <span>Submit Quiz Answers</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Quiz Results Scorecard */}
      {quizAttempt && (
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <span className="text-xs text-slate-400">Quiz Completed</span>
              <h2 className="text-xl font-bold text-white">{quizAttempt.topic}</h2>
            </div>

            <div className="text-right">
              <span className="text-2xl font-extrabold text-emerald-400">{quizAttempt.score}%</span>
              <p className="text-xs text-slate-400">
                {quizAttempt.questions.filter((q, i) => quizAttempt.userAnswers[i] === q.correctAnswerIndex).length} / {quizAttempt.totalQuestions} Correct
              </p>
            </div>
          </div>

          <div className="bg-indigo-950/40 border border-indigo-500/30 p-4 rounded-xl text-xs text-indigo-200">
            <strong className="block mb-1 text-indigo-300">Pedagogical Evaluation:</strong>
            {quizAttempt.evaluationFeedback}
          </div>

          <div className="space-y-4">
            {quizAttempt.questions.map((q, idx) => {
              const isCorrect = quizAttempt.userAnswers[idx] === q.correctAnswerIndex;
              return (
                <div key={idx} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-xs">
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-semibold text-slate-200">{idx + 1}. {q.question}</span>
                    {isCorrect ? (
                      <span className="text-emerald-400 font-bold flex items-center space-x-1 shrink-0">
                        <CheckCircle className="w-4 h-4" />
                        <span>Correct</span>
                      </span>
                    ) : (
                      <span className="text-red-400 font-bold flex items-center space-x-1 shrink-0">
                        <XCircle className="w-4 h-4" />
                        <span>Incorrect</span>
                      </span>
                    )}
                  </div>

                  <p className="text-slate-400 text-[11px] pt-1 border-t border-slate-800/80">
                    <strong>Explanation:</strong> {q.explanation}
                  </p>
                </div>
              );
            })}
          </div>

          <button
            onClick={handleGenerateQuiz}
            className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs px-4 py-2.5 rounded-xl font-medium flex items-center space-x-2"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Try Another Quiz</span>
          </button>
        </div>
      )}
    </div>
  );
};
