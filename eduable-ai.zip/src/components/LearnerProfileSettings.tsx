import React, { useState } from 'react';
import { Settings, Save, CheckCircle2, User, Award, BookOpen, ShieldAlert } from 'lucide-react';
import { LearnerProfile } from '../types';

interface LearnerProfileSettingsProps {
  profile: LearnerProfile;
  onUpdateProfile: (updated: Partial<LearnerProfile>) => void;
}

export const LearnerProfileSettings: React.FC<LearnerProfileSettingsProps> = ({
  profile,
  onUpdateProfile,
}) => {
  const [formData, setFormData] = useState<LearnerProfile>({ ...profile });
  const [savedMsg, setSavedMsg] = useState(false);
  const [newWeakTopic, setNewWeakTopic] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile(formData);
    setSavedMsg(true);
    setTimeout(() => setSavedMsg(false), 3000);
  };

  const handleAddWeakTopic = () => {
    if (!newWeakTopic.trim()) return;
    const updated = [...(formData.weakTopics || []), newWeakTopic.trim()];
    setFormData({ ...formData, weakTopics: updated });
    setNewWeakTopic('');
  };

  const handleRemoveWeakTopic = (topicToRemove: string) => {
    const updated = (formData.weakTopics || []).filter((t) => t !== topicToRemove);
    setFormData({ ...formData, weakTopics: updated });
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl flex items-center justify-between">
        <div>
          <div className="flex items-center space-x-2 text-indigo-400 font-semibold text-sm mb-1">
            <Settings className="w-4 h-4" />
            <span>Learner Adaptive Preferences</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Learner Profile & Accessibility
          </h1>
          <p className="text-slate-300 text-sm mt-1">
            NOVA Orchestrator reads these settings on every query to format explanations specifically for your cognitive needs.
          </p>
        </div>
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg space-y-4">
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2 border-b border-slate-800 pb-3">
            <User className="w-4 h-4 text-indigo-400" />
            <span>Personal Information</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Student Name</label>
              <input
                type="text"
                value={formData.name || ''}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full bg-slate-950 text-slate-100 text-xs p-3 rounded-xl border border-slate-700/80 focus:border-indigo-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Career Goal / Field of Interest</label>
              <input
                type="text"
                value={formData.careerGoal || ''}
                onChange={(e) => setFormData({ ...formData, careerGoal: e.target.value })}
                placeholder="e.g. AI Engineer, Medical Researcher"
                className="w-full bg-slate-950 text-slate-100 text-xs p-3 rounded-xl border border-slate-700/80 focus:border-indigo-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg space-y-4">
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2 border-b border-slate-800 pb-3">
            <BookOpen className="w-4 h-4 text-purple-400" />
            <span>Learning Style & Reading Level</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Primary Learning Style</label>
              <select
                value={formData.learningStyle || 'adhd_chunked'}
                onChange={(e) => setFormData({ ...formData, learningStyle: e.target.value as any })}
                className="w-full bg-slate-950 text-slate-100 text-xs p-3 rounded-xl border border-slate-700/80 focus:border-indigo-500 focus:outline-none"
              >
                <option value="adhd_chunked">ADHD Short-Chunked Bullet Points</option>
                <option value="dyslexia_friendly">Dyslexia Friendly (High Semantic Clarity)</option>
                <option value="visual">Visual & ASCII Diagram Prompts</option>
                <option value="auditory">Auditory / Speech Synthesizer Structured</option>
                <option value="reading_writing">Standard Academic Prose</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Default Target Reading Level</label>
              <select
                value={formData.readingLevel || 'high_school'}
                onChange={(e) => setFormData({ ...formData, readingLevel: e.target.value as any })}
                className="w-full bg-slate-950 text-slate-100 text-xs p-3 rounded-xl border border-slate-700/80 focus:border-indigo-500 focus:outline-none"
              >
                <option value="elementary">Elementary (Grade 5)</option>
                <option value="middle_school">Middle School (Grade 8)</option>
                <option value="high_school">High School (Grade 11)</option>
                <option value="college">College / Undergraduate</option>
                <option value="expert">Expert / Technical</option>
              </select>
            </div>
          </div>
        </div>

        {/* Weak Topics Manager */}
        <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg space-y-4">
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2 border-b border-slate-800 pb-3">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>Focus Areas & Weak Topics</span>
          </h2>

          <div className="flex space-x-2">
            <input
              type="text"
              placeholder="Add topic needing extra practice (e.g. Linear Algebra, Overfitting)..."
              value={newWeakTopic}
              onChange={(e) => setNewWeakTopic(e.target.value)}
              className="flex-1 bg-slate-950 text-slate-100 text-xs p-3 rounded-xl border border-slate-700/80 focus:border-indigo-500 focus:outline-none"
            />
            <button
              type="button"
              onClick={handleAddWeakTopic}
              className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs px-4 py-2 rounded-xl font-medium"
            >
              Add Topic
            </button>
          </div>

          <div className="flex flex-wrap gap-2 pt-2">
            {(formData.weakTopics || []).map((t, idx) => (
              <span
                key={idx}
                className="bg-amber-500/10 text-amber-300 border border-amber-500/30 text-xs px-3 py-1 rounded-full flex items-center space-x-2"
              >
                <span>{t}</span>
                <button
                  type="button"
                  onClick={() => handleRemoveWeakTopic(t)}
                  className="hover:text-amber-100 font-bold"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm py-3 rounded-xl flex items-center justify-center space-x-2 shadow-lg shadow-indigo-600/30 transition-all"
        >
          <Save className="w-4 h-4" />
          <span>Save Preference Updates</span>
        </button>

        {savedMsg && (
          <div className="bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 p-3 rounded-xl text-xs flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Learner profile updated successfully! All future NOVA AI queries will use these preferences.</span>
          </div>
        )}
      </form>
    </div>
  );
};
