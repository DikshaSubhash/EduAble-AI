import React, { useState, useEffect } from 'react';
import { Activity, Clock, ShieldCheck, CheckCircle2, Award, FileText } from 'lucide-react';
import { LearningSession } from '../types';

interface SessionAnalyticsProps {
  userId: string;
}

export const SessionAnalytics: React.FC<SessionAnalyticsProps> = ({ userId }) => {
  const [sessions, setSessions] = useState<LearningSession[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchSessionHistory();
  }, [userId]);

  const fetchSessionHistory = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/learner/sessions?userId=${userId}`);
      if (res.ok) {
        const data = await res.json();
        setSessions(data.sessions || []);
        setMetrics(data.metrics || null);
      }
    } catch (err) {
      console.error('Failed to fetch sessions:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-xl flex items-center justify-between">
        <div>
          <div className="flex items-center space-x-2 text-indigo-400 font-semibold text-sm mb-1">
            <Activity className="w-4 h-4 text-emerald-400" />
            <span>Learning Analytics & Evaluation Logs</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">
            Session History & Metrics
          </h1>
          <p className="text-slate-300 text-sm mt-1">
            Historical quality scores, factuality confidence, and accessibility compliance logged across all NOVA pipeline runs.
          </p>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 shadow-lg space-y-2">
          <span className="text-xs font-medium text-slate-400">Total Learning Sessions</span>
          <div className="text-3xl font-extrabold text-slate-100">{metrics?.totalSessions || sessions.length || 0}</div>
        </div>

        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 shadow-lg space-y-2">
          <span className="text-xs font-medium text-slate-400">Avg Quality Score</span>
          <div className="text-3xl font-extrabold text-emerald-400">
            {metrics?.averageEvaluationScore || 88}/100
          </div>
        </div>

        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 shadow-lg space-y-2">
          <span className="text-xs font-medium text-slate-400">Factuality Confidence</span>
          <div className="text-3xl font-extrabold text-indigo-400">
            {metrics?.avgFactuality || 92}%
          </div>
        </div>

        <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 shadow-lg space-y-2">
          <span className="text-xs font-medium text-slate-400">Accessibility Rating</span>
          <div className="text-3xl font-extrabold text-sky-400">
            {metrics?.avgAccessibilityCompliance || 95}%
          </div>
        </div>
      </div>

      {/* Sessions History List */}
      <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg space-y-4">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <Clock className="w-4 h-4 text-indigo-400" />
          <span>Recent Learning Activity Log</span>
        </h2>

        {sessions.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-xs">
            No session history recorded yet. Ask a question in LearnEasy Tutor to see detailed logs!
          </div>
        ) : (
          <div className="space-y-3">
            {sessions.map((s) => (
              <div key={s.id} className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="font-semibold text-slate-200">Query: "{s.query}"</span>
                  <span className="text-slate-500 font-mono text-[11px]">
                    {new Date(s.createdAt).toLocaleTimeString()}
                  </span>
                </div>

                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{s.response}</p>

                {s.evaluation && (
                  <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="text-indigo-300 capitalize font-medium">Module: {s.module?.replace('_', ' ')}</span>
                    <span className="text-emerald-400 font-semibold">Score: {s.evaluation.overallScore}/100</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
