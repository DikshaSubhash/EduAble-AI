import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import novaOrchestrator from "./src/backend/nova/NOVAOrchestrator.js";
import ragEngine from "./src/backend/rag/RAGEngine.js";
import gemmaService from "./src/backend/ai/GemmaService.js";
import learnerRepository from "./src/backend/database/repositories/LearnerRepository.js";
import sessionRepository from "./src/backend/database/repositories/SessionRepository.js";
import documentRepository from "./src/backend/database/repositories/DocumentRepository.js";
import quizRepository from "./src/backend/database/repositories/QuizRepository.js";
import { connectDatabase } from "./src/backend/database/connection.js";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ extended: true, limit: "50mb" }));

  // Connect Database (MongoDB or In-Memory)
  await connectDatabase();

  // --- API ROUTES ---

  // Health Check
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      app: "EduAble AI - Build with Gemma",
      timestamp: new Date().toISOString(),
    });
  });

  // NOVA Orchestrator Execution Endpoint
  app.post("/api/nova/query", async (req, res) => {
    try {
      const { query, userId, module, customOptions, learnerProfile } = req.body;
      if (!query) {
        return res.status(400).json({ error: "Query is required." });
      }

      const result = await novaOrchestrator.run({
        query,
        userId: userId || "default_student",
        module: module || "learn_easy",
        customOptions,
        learnerProfile,
      });

      res.json(result);
    } catch (error: any) {
      console.error("API /api/nova/query error:", error);
      res.status(500).json({ error: error.message || "NOVA execution failed." });
    }
  });

  // RAG Document Upload & Indexing Endpoint
  app.post("/api/rag/upload", async (req, res) => {
    try {
      const { title, content, base64Content, mimeType, userId } = req.body;
      if (!title || (!content && !base64Content)) {
        return res.status(400).json({ error: "Document title and text or base64 file content required." });
      }

      let buffer: Buffer | undefined;
      if (base64Content) {
        buffer = Buffer.from(base64Content.replace(/^data:[^;]+;base64,/, ""), "base64");
      }

      const indexResult = await ragEngine.indexDocument({
        title,
        content,
        buffer,
        mimeType: mimeType || "application/pdf",
      });

      // Save document record
      const docRecord = await documentRepository.save({
        id: indexResult.docId,
        userId: userId || "default_student",
        title: indexResult.title,
        fileType: mimeType || "text/plain",
        chunkCount: indexResult.indexedChunks,
        pages: indexResult.pages,
        uploadedAt: new Date(),
        summary: `Indexed ${indexResult.indexedChunks} semantic chunks across ${indexResult.pages} page(s).`,
      });

      res.json({
        success: true,
        document: docRecord,
        indexResult,
      });
    } catch (error: any) {
      console.error("API /api/rag/upload error:", error);
      res.status(500).json({ error: error.message || "Document indexing failed." });
    }
  });

  // Get Indexed Documents List
  app.get("/api/rag/documents", async (req, res) => {
    try {
      const userId = (req.query.userId as string) || "default_student";
      const docs = await documentRepository.listByUser(userId);
      res.json({ documents: docs });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Test Semantic Search on RAG Store
  app.post("/api/rag/search", async (req, res) => {
    try {
      const { query, limit } = req.body;
      const results = await ragEngine.retrieve(query || "", limit || 5);
      res.json({ query, results });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Learner Profile Get / Update
  app.get("/api/learner/profile", async (req, res) => {
    try {
      const userId = (req.query.userId as string) || "default_student";
      const profile = await learnerRepository.findByUserId(userId);
      res.json({ profile });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post("/api/learner/profile", async (req, res) => {
    try {
      const { userId, ...data } = req.body;
      const id = userId || "default_student";
      const updated = await learnerRepository.update(id, data);
      res.json({ success: true, profile: updated });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Learning History & Session Analytics
  app.get("/api/learner/sessions", async (req, res) => {
    try {
      const userId = (req.query.userId as string) || "default_student";
      const sessions = await sessionRepository.history(userId, 20);
      const metrics = await sessionRepository.getMetrics(userId);
      res.json({ sessions, metrics });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Adaptive Quiz Generation via Gemma
  app.post("/api/quiz/generate", async (req, res) => {
    try {
      const { topic, userId, questionCount } = req.body;
      const numQuestions = questionCount || 3;

      // Search RAG store for topic context if available
      const ragResults = await ragEngine.retrieve(topic || "General Science", 3);
      const contextText = ragResults.map((r) => r.text).join("\n\n");

      const prompt = `Generate a ${numQuestions}-question multiple choice quiz on the topic: "${topic}".
${contextText ? `Ground questions in this reference text if applicable:\n${contextText}` : ""}

Return a JSON array of questions with this exact structure:
[
  {
    "id": "q1",
    "question": "Clear, engaging question string",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "correctAnswerIndex": 0,
    "explanation": "Clear educational explanation why this answer is correct.",
    "topicTag": "${topic}"
  }
]`;

      const questions = await gemmaService.generateJSON(prompt, "You are an adaptive educational quiz creator.");

      res.json({
        topic,
        questions: Array.isArray(questions) ? questions : [questions],
      });
    } catch (error: any) {
      console.error("Quiz generation error:", error);
      res.status(500).json({ error: error.message || "Failed to generate quiz." });
    }
  });

  // Submit Quiz Answers Endpoint
  app.post("/api/quiz/submit", async (req, res) => {
    try {
      const { userId, topic, questions, userAnswers } = req.body;
      if (!questions || !userAnswers) {
        return res.status(400).json({ error: "Questions and user answers required." });
      }

      let correctCount = 0;
      questions.forEach((q: any, i: number) => {
        if (userAnswers[i] === q.correctAnswerIndex) {
          correctCount++;
        }
      });

      const scorePct = Math.round((correctCount / questions.length) * 100);
      const evaluationFeedback = scorePct >= 80
        ? "Fantastic mastery! You demonstrated strong conceptual recall and critical thinking."
        : scorePct >= 50
        ? "Good effort! Review the explanations below to strengthen your understanding on missed topics."
        : "Let's review this concept together in LearnEasy mode to clarify key ideas.";

      const attempt = await quizRepository.saveAttempt({
        id: `quiz_${Date.now()}`,
        userId: userId || "default_student",
        topic: topic || "Concept Review",
        score: scorePct,
        totalQuestions: questions.length,
        userAnswers,
        questions,
        evaluationFeedback,
        completedAt: new Date(),
      });

      res.json({ success: true, attempt });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // --- VITE MIDDLEWARE SETUP ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`EduAble AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
